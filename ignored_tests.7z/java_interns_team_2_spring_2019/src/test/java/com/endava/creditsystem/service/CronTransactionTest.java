package com.endava.creditsystem.service;

import com.endava.creditsystem.model.PaymentType;
import com.endava.creditsystem.model.Transaction;
import com.endava.creditsystem.model.TransactionType;
import com.endava.creditsystem.repository.TransactionRepository;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.anyObject;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
public class CronTransactionTest {

    @Mock
    private TransactionRepository transactionRepository;

    @InjectMocks
    private CronTransaction cronTransaction = new CronTransaction();

    private ArgumentCaptor<Transaction> captor = ArgumentCaptor.forClass(Transaction.class);

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    private List<Transaction> getCommitments() {
        List<Transaction> commitments = new ArrayList<>();
        commitments.add(new Transaction(1L, null, 123L, PaymentType.CAPITAL, 1, new BigDecimal(1000), LocalDate.of(2019, Month.APRIL, 15), null, TransactionType.COMMITMENT));
        commitments.add(new Transaction(2L, null, 123L, PaymentType.INTEREST_RATE, 1, new BigDecimal(100), LocalDate.of(2019, Month.APRIL, 15), null, TransactionType.COMMITMENT));
        commitments.add(new Transaction(3L, null, 123L, PaymentType.COMMISSION, 1, new BigDecimal(50), LocalDate.of(2019, Month.APRIL, 15), null, TransactionType.PAYMENT));
        return commitments;
    }

    @Test
    public void shouldCreateObjectWhichSetsFine() {
        List<Transaction> commitments = getCommitments();
        OngoingStubbing stubber;

        for (Transaction transaction : commitments) {
            stubber = when(transactionRepository.save(any(Transaction.class))).thenReturn(new Transaction());
        }

        when(transactionRepository.findAllByTransactionTypeEqualsAndPaymentDateLessThan(TransactionType.COMMITMENT, LocalDate.now())).thenReturn(commitments);
        cronTransaction.cronJob();

        for (Transaction transaction : commitments) {
            verify(transactionRepository).save(captor.capture());
            assertEquals(PaymentType.FINE, captor.getValue().getPaymentType());
            assertEquals(transaction.getIdCredit(), captor.getValue().getIdCredit());
            assertEquals(transaction.getRateNum(), captor.getValue().getRateNum());
        }
    }

    @Test
    public void shouldReturnWithoutCreatingObject() {

        when(transactionRepository.findAllByTransactionTypeEqualsAndPaymentDateLessThan(TransactionType.COMMITMENT, LocalDate.now())).thenReturn(new ArrayList<>());
        cronTransaction.cronJob();
        verify(transactionRepository, times(0)).save(anyObject());
    }
}
