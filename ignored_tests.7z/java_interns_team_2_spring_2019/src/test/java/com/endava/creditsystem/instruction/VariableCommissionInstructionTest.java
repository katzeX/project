package com.endava.creditsystem.instruction;

import com.endava.creditsystem.model.Transaction;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class VariableCommissionInstructionTest {

    @Test
    public void calculate() {
        VariableCommissionInstruction variableCommissionInstruction = new VariableCommissionInstruction();
        List<Transaction> commissionList = variableCommissionInstruction.calculate(BigDecimal.valueOf(10000), 12, LocalDate.now(), BigDecimal.valueOf(10));

        assertNotNull(commissionList);
        assertEquals(12, commissionList.size());

        BigDecimal sum = BigDecimal.ZERO;
        for (Transaction t: commissionList) {
            sum = sum.add(t.getAmount());
        }

        assertEquals(BigDecimal.valueOf(83.28), sum);
    }
}