package com.endava.creditsystem.repository;

import com.endava.creditsystem.instruction.Instruction;
import com.endava.creditsystem.model.Product;
import com.endava.creditsystem.model.ProductInstruction;
import com.endava.creditsystem.utils.InstructionFactory;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class ProductRepositoryTest {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private ProductRepository productRepository;

    @Ignore
    @Test
    public void whenFindByIdProduct_thenReturnProduct() {

        Map<String, Instruction> instructionMap = InstructionFactory.getInstructionMap();
        List<ProductInstruction> productInstructionList = new ArrayList<>();

        for (String key : instructionMap.keySet()) {
            ProductInstruction productInstruction = new ProductInstruction();
            productInstruction.setInstructionId(key);
            productInstructionList.add(productInstruction);
        }

        Product product = new Product("summer", "description", 3, 12, BigDecimal.valueOf(10000), BigDecimal.valueOf(15000),  productInstructionList);
        entityManager.persist(product);
        entityManager.flush();

        Product found = productRepository.findProductByIdProduct(product.getIdProduct());

        assertEquals(found.getIdProduct(), product.getIdProduct());
    }
}
