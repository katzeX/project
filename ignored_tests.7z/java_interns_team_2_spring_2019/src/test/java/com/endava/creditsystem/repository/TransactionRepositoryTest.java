package com.endava.creditsystem.repository;

import com.endava.creditsystem.model.PaymentType;
import com.endava.creditsystem.model.Transaction;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@RunWith(SpringRunner.class)
@DataJpaTest()
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class TransactionRepositoryTest {
    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    TestEntityManager testEntityManager;

    @Ignore
    @Test
    public void testFindByIdCredit() {
        Transaction transaction = new Transaction(null, PaymentType.CAPITAL, 1, new BigDecimal(100), LocalDate.now());
        testEntityManager.merge(transaction);
        List<Transaction> commitments = transactionRepository.findAllByIdCredit(transaction.getIdCredit());
        assert (transactionRepository.findAllByIdCredit(transaction.getIdCredit()).equals(commitments));

    }

}
