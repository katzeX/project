package com.endava.creditsystem.controller;

import com.endava.creditsystem.controller.admin.AdminController;
import com.endava.creditsystem.model.Role;
import com.endava.creditsystem.model.RoleType;
import com.endava.creditsystem.model.User;
import com.endava.creditsystem.service.UserServiceImpl;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class AdminControllerTest {
    @InjectMocks
    private AdminController adminController;

    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext context;

    @MockBean
    private UserServiceImpl userService;

    private Role role = new Role(1L, RoleType.ROLE_ADMIN);

    private User user = new User(1L, "test", "test", "test@test.com", "123abc", Arrays.asList(role), "123abc123abc");

    @Ignore
    @Test
    public void contextLoads() {
        assertThat(adminController).isNotNull();
        mockMvc = MockMvcBuilders
                .webAppContextSetup(context)
                .apply(springSecurity())
                .build();
    }
    @Ignore
    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/resources/templates/");
        viewResolver.setSuffix(".html");

        mockMvc = MockMvcBuilders.standaloneSetup(adminController)
                .setViewResolvers(viewResolver)
                .build();
    }
    @Ignore
    @Test
    public void shouldReturnAdminPage() throws Exception {
        mockMvc.perform(get("/admin"))
                .andExpect(status().isOk())
                .andExpect(view().name("/admin/adminPage"));
    }
    @Ignore
    @Test
    public void shouldReturnChangeRolesPage() throws Exception {
        List<User> users = new ArrayList<>();

        users.add(new User(1L, "test", "test", "test@test.com", "123abc", Arrays.asList(role), "123abc123abc"));

        when(userService.findAll()).thenReturn(users);
        mockMvc.perform(get("/admin/change-roles"))
                .andExpect(status().isOk())
                .andExpect(view().name("/admin/change-roles"))
                .andExpect(model().attributeExists("users"));
    }

    @Ignore
    @Test
    public void shouldReturnSecondViewUpdate() throws Exception {


        when(userService.getUserById(anyLong())).thenReturn(user);
        when(userService.getRoles()).thenReturn(Arrays.asList(role));

        mockMvc.perform(get("/admin/update-roles/" + 1))
                .andExpect(status().isOk())
                .andExpect(view().name("/admin/update-roles"))
                .andExpect(model().attributeExists("user"))
                .andExpect(model().attributeExists("getRoles"));
    }

    @Ignore
    @Test
    public void shouldReturnUserByIdAndRedirect() throws Exception {

        when(userService.getUserById(anyLong())).thenReturn(user);
        mockMvc.perform(get("/update-roles/" + 1))
                .andExpect(view().name("redirect:/admin/update-roles"))
                .andExpect(redirectedUrl("/admin/update-roles"))
                .andReturn();
    }


    @Ignore
    @Test
    public void shouldUpdateRoleAndRedirect() throws Exception {

        mockMvc.perform(post("/admin/roles-update/")
                .requestAttr("getIdRole", "ertfy")
                .requestAttr("user", user))
                .andExpect(view().name("redirect:/admin/change-roles"))
                .andExpect(redirectedUrl("/admin/change-roles"))
                .andReturn();
    }

}
