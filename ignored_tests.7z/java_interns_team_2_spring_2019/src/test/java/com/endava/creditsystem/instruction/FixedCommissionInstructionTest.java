package com.endava.creditsystem.instruction;

import com.endava.creditsystem.model.Transaction;
import org.junit.Ignore;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class FixedCommissionInstructionTest {

    @Test
    public void calculate() {
        FixedCommissionInstruction fixedCommissionInstruction = new FixedCommissionInstruction();
        List<Transaction> commissionList = fixedCommissionInstruction.calculate(BigDecimal.ZERO, 10, LocalDate.now(), BigDecimal.valueOf(50));

        assertNotNull(commissionList);
        assertEquals(10, commissionList.size());

        BigDecimal sum = BigDecimal.ZERO;
        for (Transaction t: commissionList) {
            sum = sum.add(t.getAmount());
        }

        assertEquals(500, sum.intValue());
    }
}