package com.endava.creditsystem.service;

import com.endava.creditsystem.dto.PaymentDTO;
import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.CreditStatus;
import com.endava.creditsystem.model.PaymentType;
import com.endava.creditsystem.model.Transaction;
import com.endava.creditsystem.model.TransactionStatus;
import com.endava.creditsystem.model.TransactionType;
import com.endava.creditsystem.repository.CreditRepository;
import com.endava.creditsystem.repository.TransactionRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


@RunWith(SpringJUnit4ClassRunner.class)
public class TransactionServiceTest extends TransactionService {


    @InjectMocks
    private TransactionService transactionService;

    @MockBean
    private TransactionRepository transactionRepository;

    @MockBean
    private CreditRepository creditRepository;

    @MockBean
    private RestApiService restApiService;

    @MockBean
    private WebSocketDistributeService webSocketDistributeService;

    @MockBean
    private UserService userService;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }


    public List<Transaction> getCommitments() {
        List<Transaction> commitments = new ArrayList<>();
        commitments.add(new Transaction(1L, 555555L, 123L, PaymentType.INTEREST_RATE, 1, new BigDecimal(100), LocalDate.now(), null, TransactionType.COMMITMENT));
        commitments.add(new Transaction(2L, 555555L, 123L, PaymentType.COMMISSION, 1, new BigDecimal(50), LocalDate.now(), null, TransactionType.COMMITMENT));
        commitments.add(new Transaction(3L, 555555L, 123L, PaymentType.CAPITAL, 1, new BigDecimal(1000), LocalDate.now(), null, TransactionType.PAYMENT));
        return commitments;
    }


    @Test
    public void shouldFindDataAndPayForTransactionSuccessful() {
        PaymentDTO paymentDTO = new PaymentDTO(123L, new BigDecimal(1500));
        TransactionService transactionService = spy(TransactionService.class);
        List<Transaction> commitments = getCommitments();
        Transaction min = new Transaction(1L, 555555L, 123L, PaymentType.INTEREST_RATE, 1, new BigDecimal(100), LocalDate.now(), null, TransactionType.COMMITMENT);
        Credit credit = new Credit(123L, 555555L, null, new BigDecimal(5000), 6, LocalDate.now(), null, CreditStatus.ACTIVE);


        when(transactionRepository.findFirstByIdCreditAndTransactionTypeEqualsOrderByRateNumAsc(paymentDTO.getIdCredit(), TransactionType.COMMITMENT)).thenReturn(min);
        when(transactionRepository.findAllByIdCreditOrderByPaymentTypeDesc(paymentDTO.getIdCredit())).thenReturn(commitments);
        when(transactionRepository.findTransactionByIdCreditAndPaymentTypeEquals(paymentDTO.getIdCredit(), PaymentType.FINE)).thenReturn(null);
        when(transactionRepository.findAllByIdCredit(paymentDTO.getIdCredit())).thenReturn(commitments);
        when(restApiService.getUsersBalance()).thenReturn(new BigDecimal(100000));
        when(creditRepository.findCreditByIdCredit(paymentDTO.getIdCredit())).thenReturn(credit);
        when(transactionService.returnSumAfterPayment()).thenReturn(new BigDecimal(100));
        when(restApiService.payForCredit(eq(min.getIdAccount()), any())).thenReturn(HttpStatus.OK);

        assertThat(checkData(paymentDTO, null), is(TransactionStatus.INTEGRAL));

    }


    @Test
    public void shouldFindDataAndReturnTransactionStatusUnpaid() {
        PaymentDTO paymentDTO = new PaymentDTO(123L, new BigDecimal(100));
        when(restApiService.getUsersBalance()).thenReturn(new BigDecimal(10));

        assertThat(checkData(paymentDTO, null), is(TransactionStatus.UNPAID));
    }

    @Test
    public void shouldFindDataAndCloseTheCredit() {
        PaymentDTO paymentDTO = new PaymentDTO(123L, new BigDecimal(100));
        Credit credit = new Credit(123L, null, null, new BigDecimal(5000), 6, LocalDate.now(), null, CreditStatus.ACTIVE);
        when(restApiService.getUsersBalance()).thenReturn(new BigDecimal(100000));
        when(transactionRepository.findFirstByIdCreditAndTransactionTypeEqualsOrderByRateNumAsc(paymentDTO.getIdCredit(), TransactionType.COMMITMENT)).thenReturn(null);
        when(transactionRepository.findTransactionsByTransactionTypeEqualsAndIdCreditEquals(TransactionType.COMMITMENT, paymentDTO.getIdCredit())).thenReturn(new ArrayList<>());
        when(creditRepository.findCreditByIdCredit(paymentDTO.getIdCredit())).thenReturn(credit);
        when(userService.getLoggedUser()).thenReturn("user");

        assertThat(transactionService.checkData(paymentDTO, null), is(TransactionStatus.CLOSED));
        verify(creditRepository, times(1)).saveAndFlush(credit);

    }

    @Test
    public void shouldReturnCreditsByUser() {
        List<Credit> actualCredits = new ArrayList<>();
        actualCredits.add(new Credit());

        when(creditRepository.findCreditByIdAccountAndStatusEquals(null, CreditStatus.ACTIVE)).thenReturn(actualCredits);
        transactionService.getAllCreditsByUser(null);

        assertThat(actualCredits, is(actualCredits));
    }

    @Test
    public void shouldReturnEmptyListWhenMethodGetAllCreditsByUserIsCalled() {
        when(creditRepository.findCreditByIdAccountAndStatusEquals(null, CreditStatus.ACTIVE)).thenReturn(new ArrayList<>());
        transactionService.getAllCreditsByUser(null);

        assertTrue(transactionService.getAllCreditsByUser(null).isEmpty());
    }

    @Test
    public void shouldReturnTransactions() {
        List<Transaction> actualCommitments = getCommitments();

        when(transactionRepository.findAllByIdCreditAndPaidDateIsLessThanEqual(123L, LocalDateTime.now())).thenReturn(actualCommitments);
        transactionService.getAllTransactions(null);

        assertThat(actualCommitments, is(actualCommitments));
    }

    @Test
    public void shouldReturnSumForPayment() {
        PaymentDTO paymentDTO = new PaymentDTO(123L, new BigDecimal(1500));
        Transaction min = new Transaction(1L, null, 123L, PaymentType.INTEREST_RATE, 1, new BigDecimal(100), LocalDate.now(), null, TransactionType.COMMITMENT);

        when(transactionRepository.findAllByIdCreditOrderByPaymentTypeDesc(paymentDTO.getIdCredit())).thenReturn(getCommitments());
        when(transactionRepository.findFirstByIdCreditAndTransactionTypeEqualsOrderByRateNumAsc(paymentDTO.getIdCredit(), TransactionType.COMMITMENT)).thenReturn(min);
        transactionService.getSumForPayment(123L);

        assertThat(transactionService.getSumForPayment(123L), is(new BigDecimal(1150)));
    }

    @Test
    public void shouldSaveAllTransactions() {
        transactionService.saveAll(getCommitments());
        verify(transactionRepository, times(1)).saveAll(getCommitments());
    }
}