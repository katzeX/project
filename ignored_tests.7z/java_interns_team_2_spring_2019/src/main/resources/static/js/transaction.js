$("#transactionTable, #sumForPayment, #userSumForPayment, #payForCredit").css("visibility", "hidden");

var user;
$.ajax({
    method: "GET",
    xhrFields: {
        withCredentials: true
    },
    url: "api/account/idAccount",
    success: function (response) {
        user = response;
        fillDropDownList(response);
    }
});

$("#payForCredit").on("click", function (event) {
    event.preventDefault();
    event.stopPropagation();

    $.ajax({
        method: "POST",
        xhrFields: {
            withCredentials: true
        },
        url: "/transaction/" + user,
        data: JSON.stringify(prepareData()),
        contentType: "application/json",
        statusCode: {
            202: function () {
                $("#modalContent").val("The payment was paid partially.").html("The payment was paid partially.");
                $('#myModal').css("display", "block");
                getAllTransactions($("#idCredit").val());
            },
            200: function () {
                $("#modalContent").val("The payment was paid integrally.").html("The payment was paid integrally.");
                $('#myModal').css("display", "block");
                getAllTransactions($("#idCredit").val());
            },
            400: function () {
                $("#modalContent").val("Unsuccessful transaction. It seems that you do not have enough money for payment.").html("Unsuccessful transaction. It seems that you do not have enough money for payment.");
                $('#myModal').css("display", "block");
            },
            404: function () {
                $("#modalContent").val("Unsuccessful transaction. It seems that you do not have active credits or transactions.").html("Unsuccessful transaction. It seems that you do not have active credits or transactions.");
                $('#myModal').css("display", "block");
            }
        }
    })
});

function prepareData() {
    return {
        idCredit: $("#idCredit").val(),
        sum: $("#sumForPayment").val()
    }
}

function getAllTransactions(idCredit) {
    $.ajax({
        method: "GET",
        xhrFields: {
            withCredentials: true
        },
        url: "api/credit/" + idCredit + "/transactions",
        success: function (response) {
            fillTable(response);
        }
    });
}

function getSumForPayment(idCredit) {
    $.ajax({
        method: "GET",
        xhrFields: {
            withCredentials: true
        },
        url: "/api/credit/" + idCredit + "/transactions/payment/sum",
        success: function (response) {
            $('#sum').val(response);
            $('#sumForPayment').val(response);

            setTimeout(function () {
                if (isEmpty(response)) {
                    $("#modalContent").val("You do not have active payments.").html("You do not have active payments.");
                    $('#myModal').css("display", "block");
                    setTimeout(function () {
                        $(location).attr("href", "http://localhost:8081/client/show-products");
                        $('.payment').removeAttr("href");
                    }, 2000);
                }
            }, 5000);
        }
    });
}

function fillTable(data) {
    $("#transactionTable").css("visibility", "visible");
    let tbody = "";
    for (let i = 0; i < data.length; i++) {

        tbody += "<tr>";
        tbody += "<tr>";
        tbody += "<td>" + data[i].idCredit + "</td>";
        tbody += "<td>" + data[i].paymentType + "</td>";
        tbody += "<td>" + data[i].amount + "</td>";
        tbody += "<td>" + data[i].rateNum + "</td>";

        if (data[i].transactionType === "PAYMENT")
            tbody += "<td>Paid</td>";

        tbody += "<td>" + data[i].paidDate + "</td>"
        tbody += "</tr>";
        tbody += "</tr>";
    }
    $("#transactionTable tbody").html(tbody);
}

function isEmpty(obj) {
    return (!obj || 0 === obj.length);
}

function fillDropDownList(idAccount) {
    var selectIdCredit = $('#idCredit').val([]).html('');
    selectIdCredit.append($("<option></option>").val('').html('Please Select ID Credit:'));

    $('#sumForPayment').val('').html('');
    $.ajax({
        url: 'api/credit/' + idAccount,
        type: 'GET',
        success: function (response) {
            console.log(response);
            if (isEmpty(response)) {
                $("#modalContent").val("You do not have active credits.").html("You do not have active credits.");
                $('#myModal').css("display", "block");
                setTimeout(function () {
                    $(location).attr("href", "http://localhost:8081");
                    $('.payment').addClass('disabled');
                }, 30000);

            }

            $.each(response, function (i, credit) {
                selectIdCredit.append($("<option></option>").val(credit.idCredit).html(credit.idCredit));
            });
            selectIdCredit.change(function () {
                getSumForPayment($("#idCredit :selected").val());
            });
        }
    });
}

function showInputForPayment() {

    if ($("#enter:checked").val()) {
        $("#userSumForPayment, #payForCredit").css("visibility", "visible");
    } else {
        $("#userSumForPayment").css("visibility", "hidden");
        $("#payForCredit").css("visibility", "visible");
    }
}

function checkUserSumForPayment() {
    var userSum = $.trim($("#userSumForPayment").val());
    var paymentSum = $('#sum').val();
    console.log(paymentSum);

    if ($("#enter:checked").val()) {

        if ((userSum.length === 0) && ($("#userSumForPayment").is(":visible"))) {
            $("#modalContent").val("If you want to pay another sum, be sure that you have entered it.").html("If you want to pay another sum, be sure that you have entered it.");
            $('#sumForPayment').val(paymentSum);
        } else {
            showInputForPayment();
            $('#sumForPayment').val(userSum);
        }

    } else {
        $('#sumForPayment').val(paymentSum);
    }
}

$('.close')[0].onclick = function () {
    $('#myModal').css("display", "none");
};

var $loading = $('#loader').hide();

$(document).ajaxStart(function () {
    $loading.show();
})
    .ajaxStop(function () {
        $loading.hide();
    });