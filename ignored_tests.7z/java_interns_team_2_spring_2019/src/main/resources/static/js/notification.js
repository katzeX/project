

$.ajax({
    method: "GET",
    xhrFields: {
        withCredentials: true
    },
    url: "/client/api/account/notifications/all",
    success: function (response) {
        fillNotificationTable(response);
    }
});

function fillNotificationTable(response) {
    $("#notificationTable").css("visibility", "visible");
    let tbody = "";
    for (let i = 0; i < response.length; i++) {

        tbody += "<tr>";
        tbody += "<tr>";
        tbody += "<td>" + response[i].content + "</td>";
        tbody += "</tr>";
    }
    $("#notificationTable tbody").html(tbody);
}

