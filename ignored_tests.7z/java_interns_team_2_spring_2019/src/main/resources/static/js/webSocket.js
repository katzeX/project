var stompClient = null;
var token = "";
var numOfCurrentNotifications;

$.ajax({
    method: "GET",
    xhrFields: {
        withCredentials: true
    },
    url: "/client/api/account/notifications",
    success: function (response) {

        $('#notificationNumber').val(response).html(response);

        numOfCurrentNotifications  = parseInt($('#notificationNumber').val());
        if (response === 0) {
            $('#notificationNumber').css("visibility", "hidden");
        }
    }
});

$( document ).ready(function() {

    getToken();
    sendNotification();

});


function sendNotification() {
    var socket = new SockJS('/send-notifications');
    stompClient = Stomp.over(socket);
    stompClient.connect({}, function () {

        stompClient.subscribe('/client/' + token + '/notifications', function () {
            $('#notificationNumber').css("visibility", "visible");

            const appTimer = setTimeout(showGreeting, 1000);
            setTimeout(() => {
                console.log('Cancel the setTimeout event');
            $('#notificationNumber').css("color", "white");
            $('#notificationNumber').css(" background-color", "rgb(222, 65, 27)");

          //  $("#notificationNumber").html(numOfCurrentNotifications);

            clearTimeout(appTimer);
        }, 3000);
        });
    });
}

function showGreeting() {
    numOfCurrentNotifications++;
        $("#notificationNumber").attr("value", numOfCurrentNotifications);
        $("#notificationNumber").html(numOfCurrentNotifications);
        $('#notificationNumber').css("color", "red");
        $('#notificationNumber').css("font-size", "1em");

}


function  getToken() {

    $.ajax({
        method: "GET",
        url: "/api/account/token",
        success: function (response) {
            console.log(response);
            token = response;
            sendNotification();
        }
    });
}

$('#notificationLink').click(function () {
    $('#notificationNumber').css("visibility", "hidden");
    $.ajax({
        method: "GET",
        xhrFields: {
            withCredentials: true
        },
        url: "/client/api/account/status",
        success: function () {
            console.log("CHANGED");
            }
    });
})