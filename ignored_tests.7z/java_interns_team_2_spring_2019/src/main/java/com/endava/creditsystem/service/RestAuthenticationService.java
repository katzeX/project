package com.endava.creditsystem.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import java.util.Base64;

@Service
public class RestAuthenticationService {

    @Value("${rest.username}")
    private String username;

    @Value("${rest.password}")
    private String password;

    public HttpHeaders createHeadersWithAuthentication() {
        HttpHeaders headers = new HttpHeaders();
        String notEncoded = username + ":" + password;
        String encodedAuth = Base64.getEncoder().encodeToString(notEncoded.getBytes());

        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add("Authorization", "Basic " + encodedAuth);

        return headers;
    }
}