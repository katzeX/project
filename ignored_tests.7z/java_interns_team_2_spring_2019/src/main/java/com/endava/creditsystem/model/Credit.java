package com.endava.creditsystem.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "credit")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Credit {

    @Id
    @Column(name = "id_credit")
    private Long idCredit = System.currentTimeMillis();

    @Column(name = "id_account")
    private Long idAccount;

    @Column(name = "id_product")
    private Integer idProduct;

    @Column(name = "amount")
    private BigDecimal amount;

    @Column(name = "period")
    private Integer period;

    @Column(name = "start_date")
    private LocalDate startDate;

    @Column(name = "final_date")
    private LocalDate finalDate;

    @Column(name = "status")
    @Enumerated(EnumType.STRING)
    private CreditStatus status = CreditStatus.ACTIVE;
}
