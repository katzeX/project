package com.endava.creditsystem.controller;

import com.endava.creditsystem.dto.PaymentDTO;
import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.Transaction;
import com.endava.creditsystem.model.TransactionStatus;
import com.endava.creditsystem.service.NotificationService;
import com.endava.creditsystem.service.RestApiService;
import com.endava.creditsystem.service.RestAuthenticationService;
import com.endava.creditsystem.service.TransactionService;
import com.endava.creditsystem.service.WebSocketDistributeService;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.List;
@Log4j
@RestController
@RequiredArgsConstructor
public class TransactionRestController {

    @Autowired
    private TransactionService transactionService;

    @Autowired
    WebSocketDistributeService webSocketDistributeService;

    @Autowired
    RestAuthenticationService restAuthenticationService;

    @Autowired
    RestApiService restApiService;

    @Autowired
    NotificationService notificationService;


    private HttpStatus checkStatus(TransactionStatus transactionStatus) {
        if (transactionStatus == TransactionStatus.PARTIAL) {
            return HttpStatus.ACCEPTED;
        } else if (transactionStatus == TransactionStatus.INTEGRAL) {
            return HttpStatus.OK;
        } else if (transactionStatus == TransactionStatus.UNPAID)
            return HttpStatus.BAD_REQUEST;
        else if (transactionStatus == TransactionStatus.CLOSED)
            return HttpStatus.NOT_FOUND;
        return HttpStatus.BAD_REQUEST;
    }

    @GetMapping("/api/credit/{idCredit}/transactions")
    public List<Transaction> getAllTransactions(@PathVariable Long idCredit) {
        return transactionService.getAllTransactions(idCredit);
    }

    @GetMapping("/api/account/idAccount")
    public Long getIdAccount() {
        return restApiService.getCurrentIdAccount();
    }

    @GetMapping("/api/credit/{idCredit}/transactions/payment/sum")
    public BigDecimal getSumForPayment(@PathVariable Long idCredit) {
        return transactionService.getSumForPayment(idCredit);
    }

    @GetMapping("/api/credit/{idAccount}")
    public List<Credit> getAllCreditsByUser(@PathVariable Long idAccount) {
        return transactionService.getAllCreditsByUser(idAccount);
    }

    @GetMapping("/api/account/balance")
    public BigDecimal getIdAccountAndBalance() {
        return restApiService.getUsersBalance();
    }

    @PostMapping(value = "/transaction/{idAccount}")
    public ResponseEntity getData(@RequestBody PaymentDTO payment, @PathVariable Long idAccount) {
        TransactionStatus status = transactionService.checkData(payment, idAccount);
        log.info("Check transactions status for account" + idAccount);
        return new ResponseEntity(checkStatus(status));
    }
}