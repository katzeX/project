package com.endava.creditsystem.service;

import com.endava.creditsystem.instruction.FineInstruction;
import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.PaymentType;
import com.endava.creditsystem.model.Product;
import com.endava.creditsystem.model.ProductInstruction;
import com.endava.creditsystem.model.Transaction;
import com.endava.creditsystem.model.TransactionType;
import com.endava.creditsystem.repository.CreditRepository;
import com.endava.creditsystem.repository.ProductInstructionRepository;
import com.endava.creditsystem.repository.ProductRepository;
import com.endava.creditsystem.repository.TransactionRepository;
import lombok.extern.log4j.Log4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Log4j
@Service
public class CronTransaction {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private CreditRepository creditRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private ProductInstructionRepository productInstructionRepository;

    private void saveFineTransactions() {
        List<Transaction> remainingTransactions = transactionRepository.findAllByTransactionTypeEqualsAndPaymentDateLessThan(TransactionType.COMMITMENT, LocalDate.now());

        if (remainingTransactions.isEmpty()) {
            log.info("No remaining transactions");
        }

        Map<Long, List<Transaction>> commitmentsById = remainingTransactions.stream()
                .collect(Collectors.groupingBy(Transaction::getIdCredit));

        for (Map.Entry<Long, List<Transaction>> entry : commitmentsById.entrySet()) {
            Long creditId = entry.getKey();
            BigDecimal sum = BigDecimal.ZERO;

            Integer currentRateNum = 0;

            for (Transaction t : entry.getValue()) {
                if (!t.getPaymentType().equals(PaymentType.FINE)) {
                    sum = sum.add(t.getAmount());
                    if (t.getPaymentType().equals(PaymentType.CAPITAL) && t.getRateNum() > currentRateNum) {
                        currentRateNum = t.getRateNum();
                    }
                }
            }

            BigDecimal value = getFineInstructionValue(creditId);
            List<Transaction> fineTransactionList = prepareFineTransactionList(creditId, sum, currentRateNum, value);
            transactionRepository.saveAll(fineTransactionList);
        }
    }

    private List<ProductInstruction> getProductInstructionList(Long creditId) {
        Credit credit = creditRepository.findCreditByIdCredit(creditId);
        Product product = productRepository.findProductByIdProduct(credit.getIdProduct());

        return productInstructionRepository.findAllByProduct(product);
    }

    private BigDecimal getFineInstructionValue(Long creditId) {
        List<ProductInstruction> productInstructionList = getProductInstructionList(creditId);

        for (ProductInstruction productInstruction : productInstructionList) {
            if (productInstruction.getInstructionId().equals("FineInstruction")) {
                return productInstruction.getValue();
            }
        }

        return BigDecimal.ZERO;
    }

    private List<Transaction> prepareFineTransactionList(Long creditId, BigDecimal sum, Integer currentRateNum, BigDecimal value) {
        FineInstruction fineInstruction = new FineInstruction();
        List<Transaction> fineTransactionList = fineInstruction.calculate(sum, currentRateNum, LocalDate.now(), value);

        for (Transaction t : fineTransactionList) {
            t.setIdCredit(creditId);
            log.info("Fine for credit: + " + t.getIdCredit()  + " was accrued with amount: " + t.getAmount());
        }

        return fineTransactionList;
    }

    @Scheduled(cron = "0 0 12 * * ?")
    public void cronJob() {
        log.info("Cron started at: " +  LocalDateTime.now());
        saveFineTransactions();
        log.info("Cron finished at: " +  LocalDateTime.now());
    }
}
