package com.endava.creditsystem.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "notification")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Notification {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_notification")
    private Long idNotification;

    @Column(name = "status")
    @Enumerated(value = EnumType.STRING)
    private NotificationStatus notificationStatus = NotificationStatus.UNREAD;

    @Column(name = "content")
    private String content;

    @Column(name = "date")
    private LocalDateTime date = LocalDateTime.now();

    @Column(name = "user_name")
    private String userName;

    public Notification(String content, String userName) {
        this.content = content;
        this.userName = userName;
    }
}
