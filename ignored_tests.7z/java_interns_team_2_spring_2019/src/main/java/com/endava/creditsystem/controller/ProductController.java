package com.endava.creditsystem.controller;

import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.Product;
import com.endava.creditsystem.service.EmailService;
import com.endava.creditsystem.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ProductController {

    @Autowired
    private EmailService emailService;

    @Autowired
    private ProductService productService;

    @GetMapping(value = "/admin/add-product")
    public String showProductForm(Model model) {
        Product product = new Product();

        product.setProductInstructions(productService.getProductInstructionsKeyList());

        model.addAttribute("product", product);

        return "/admin/credit_product";
    }

    @PostMapping(value = "/admin/add-product")
    public String addProduct(@ModelAttribute("product") Product product) {
        productService.save(productService.removeUnusedInstructions(product));
        return "redirect:/client/show-products";
    }

    @GetMapping(value = "/client/show-products")
    public String showProducts(Model model) {
        model.addAttribute("productsList", productService.findAll());

        return "/client/credit_products_list";
    }

    @GetMapping(value = "/client/show-graphic")
    public String showGraphic(Model model) {
        model.addAttribute("productsList", productService.findAll());
        model.addAttribute("credit", new Credit());

        return "/client/set_credit_details";
    }

    @PostMapping(value = "/client/show-graphic")
    public String showGraphic(@ModelAttribute("credit") Credit credit, Model model) {
        Product product = productService.findProductByIdProduct(credit.getIdProduct());

        model.addAttribute("graphic", productService.fillGraphic(credit.getAmount(), product, credit.getPeriod()));

        return "/client/set_credit_details";
    }
}
