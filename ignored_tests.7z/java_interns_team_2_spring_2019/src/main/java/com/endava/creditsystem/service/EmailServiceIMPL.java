package com.endava.creditsystem.service;

import com.endava.creditsystem.email.Email;
import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.CustomerPersonalData;
import lombok.extern.log4j.Log4j;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.velocity.VelocityEngineUtils;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Service
@Log4j
public class EmailServiceIMPL implements EmailService {

    private static final String CHARSET_UTF8 = "UTF-8";


    @Autowired
    private ValidateCredit validateCredit;

    @Autowired
    private VelocityEngine velocityEngine;

    @Override
    public void sendApprovalEmailToClient(String clientEmail, Long idCredit) {
        CustomerPersonalData customerPersonalData = validateCredit.getClientByCreditIDRest(idCredit);
        Credit credit = validateCredit.getCreditByID(idCredit);
        String productName = validateCredit.getProductNameByIDProductFromCredit(idCredit);
        Email email = new Email();
        email.setRecipient(clientEmail);
        email.setSubject("Credit Approval");

        try {
            Map model = modelForEmail(customerPersonalData, credit, productName);
            email.setContent(VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, "/templates/email/credit_approval_template.vm", CHARSET_UTF8, model));
        } catch (Exception e) {
            log.warn(e.getMessage() + " Cause: " + e.getCause());
        }
        try {
            email.sendmail();
            log.info("Email sent to: " + clientEmail);
        } catch (MessagingException | IOException e) {
            log.warn(e.getMessage() + ": " + clientEmail + " Cause: " + e.getCause());
        }
    }

    @Override
    public void sendRejectingEmailToClient(String clientEmail, Long idCredit) {
        CustomerPersonalData customerPersonalData = validateCredit.getClientByCreditIDRest(idCredit);
        Credit credit = validateCredit.getCreditByID(idCredit);
        String productName = validateCredit.getProductNameByIDProductFromCredit(idCredit);
        Email email = new Email();
        email.setRecipient(clientEmail);
        email.setSubject("Credit System");

        try {
            Map model = modelForEmail(customerPersonalData, credit, productName);
            email.setContent(VelocityEngineUtils.mergeTemplateIntoString(velocityEngine, "/templates/email/credit_rejecting_template.vm", CHARSET_UTF8, model));
        } catch (Exception e) {
            log.warn(e.getMessage() + " Cause: " + e.getCause());
        }

        try {
            email.sendmail();
            log.info("Email sent to: " + clientEmail);
        } catch (MessagingException | IOException e) {
            log.warn(e.getMessage() + ": " + clientEmail + " Cause: " + e.getCause());
        }

    }

    private Map modelForEmail(CustomerPersonalData customerPersonalData, Credit credit, String productName) {
        Map model = new HashMap<>();
        model.put("userName", customerPersonalData.getName());
        model.put("userSurname", customerPersonalData.getSurname());
        model.put("creditSum", credit.getAmount());
        model.put("creditPeriod", credit.getPeriod());
        model.put("productName", productName);
        return model;
    }


}