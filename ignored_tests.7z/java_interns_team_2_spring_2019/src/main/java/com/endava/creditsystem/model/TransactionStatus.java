package com.endava.creditsystem.model;

public enum TransactionStatus {
    INTEGRAL,
    PARTIAL,
    UNPAID,
    CLOSED
}
