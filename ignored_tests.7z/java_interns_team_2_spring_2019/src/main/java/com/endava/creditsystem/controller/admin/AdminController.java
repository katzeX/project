package com.endava.creditsystem.controller.admin;

import com.endava.creditsystem.model.User;
import com.endava.creditsystem.service.EmailService;
import com.endava.creditsystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AdminController {
    @Autowired
    EmailService emailService;

    @Autowired
    UserService userService;

    @GetMapping(value = "/admin")
    public String adminPage() {
        return "/admin/adminPage";
    }


    @GetMapping(value = "/admin/change-roles")
    public String adminChangeRoles(Model model) {
        model.addAttribute("users", userService.findAll());
        return "/admin/change-roles";
    }

    @RequestMapping("/admin/update-roles/{id}")
    public String secondViewUpdate(Model model, @PathVariable Long id) {
        model.addAttribute("user", userService.getUserById(id));
        model.addAttribute("getRoles", userService.getRoles());
        return "/admin/update-roles";
    }

    @GetMapping(value = "/update-roles/{id}")
    public String getUserById(@PathVariable Long id) {
        userService.getUserById(id);
        return "redirect:/admin/update-roles";
    }


    @PostMapping(value = "/admin/roles-update")
    public String updateRole(@ModelAttribute User user, @RequestParam(required = false) String getIdRole) {
        int idRole = Integer.parseInt(getIdRole);
        userService.updateRole(user.getId(), idRole);
        return "redirect:/admin/change-roles";
    }


}
