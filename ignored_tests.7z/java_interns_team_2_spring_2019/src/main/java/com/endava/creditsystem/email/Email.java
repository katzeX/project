package com.endava.creditsystem.email;

import lombok.Data;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.Properties;

@Data
public class Email {
    private String recipient;
    private String subject;
    private String content;


    public void sendmail() throws MessagingException, IOException {
        Properties props = new Properties();
        InputStream inputStream = Email.class.getClassLoader().getResourceAsStream("config.properties");
        props.load(inputStream);
        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(props.getProperty("e.email"), props.getProperty("e.password"));
            }
        });
        Message msg = new MimeMessage(session);

        msg.setFrom(new InternetAddress(props.getProperty("e.email"), false));

        msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipient));
        msg.setSubject(subject);
        msg.setContent(content, "text/html");
        msg.setSentDate(new Date());

        Transport.send(msg);
    }
}
