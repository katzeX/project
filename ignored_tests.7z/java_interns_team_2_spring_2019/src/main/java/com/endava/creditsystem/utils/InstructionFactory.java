package com.endava.creditsystem.utils;

import com.endava.creditsystem.instruction.AnnuityCapitalInterestInstruction;
import com.endava.creditsystem.instruction.CapitalInstruction;
import com.endava.creditsystem.instruction.FineInstruction;
import com.endava.creditsystem.instruction.FixedCommissionInstruction;
import com.endava.creditsystem.instruction.Instruction;
import com.endava.creditsystem.instruction.InterestInstruction;
import com.endava.creditsystem.instruction.VariableCommissionInstruction;

import java.util.Map;
import java.util.TreeMap;

public class InstructionFactory {
    private static Map<String, Instruction> instructionCalculatorMap = new TreeMap<>();

    public static Map<String, Instruction> getInstructionMap() {
        Instruction instruction = new AnnuityCapitalInterestInstruction();
        instructionCalculatorMap.put(AnnuityCapitalInterestInstruction.class.getSimpleName(), instruction);
        instruction = new CapitalInstruction();
        instructionCalculatorMap.put(CapitalInstruction.class.getSimpleName(), instruction);
        instruction = new FixedCommissionInstruction();
        instructionCalculatorMap.put(FixedCommissionInstruction.class.getSimpleName(), instruction);
        instruction = new InterestInstruction();
        instructionCalculatorMap.put(InterestInstruction.class.getSimpleName(), instruction);
        instruction = new VariableCommissionInstruction();
        instructionCalculatorMap.put(VariableCommissionInstruction.class.getSimpleName(), instruction);
        instruction = new FineInstruction();
        instructionCalculatorMap.put(FineInstruction.class.getSimpleName(), instruction);

        return instructionCalculatorMap;
    }
}
