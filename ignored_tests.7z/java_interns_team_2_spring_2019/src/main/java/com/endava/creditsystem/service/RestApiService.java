package com.endava.creditsystem.service;

import lombok.extern.log4j.Log4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.Map;

@Service
@Log4j
public class RestApiService {

    @Value("${rest.address}")
    public String restServiceURL;

    @Autowired
    RestAuthenticationService restAuthenticationService;

    @Autowired
    UserService userService;

    private RestTemplate restTemplate = new RestTemplate();
    private ParameterizedTypeReference<Map<String, String>> typeStringRef = new ParameterizedTypeReference<Map<String, String>>() {
    };

    public Long getCurrentIdAccount() {
        String username = userService.getLoggedUser();
        HttpEntity request = new HttpEntity<>(restAuthenticationService.createHeadersWithAuthentication());
        ResponseEntity<Map<String, String>> response = restTemplate.exchange(restServiceURL + "account/" + username, HttpMethod.GET, request, typeStringRef);

        return Long.parseLong(getBodyValue(response));
    }

    public BigDecimal getSalaryOfCurrentUser() {
        String username = userService.getLoggedUser();
        HttpEntity request = new HttpEntity<>(restAuthenticationService.createHeadersWithAuthentication());
        ResponseEntity<Map<String, String>> response = restTemplate.exchange(restServiceURL + "salary/" + username, HttpMethod.GET, request, typeStringRef);

        return new BigDecimal(getBodyValue(response));

    }

    private String getBodyValue(ResponseEntity<Map<String, String>> response) {
        String value = "";

        for (Map.Entry<String, String> entry : response.getBody().entrySet()) {
            value = entry.getValue();
        }
        return value;
    }

    public HttpStatus payForCredit(Long idAccount, BigDecimal sum) {
        HttpEntity request = new HttpEntity<>(restAuthenticationService.createHeadersWithAuthentication());
        ResponseEntity<String> response = restTemplate.exchange(restServiceURL + "/credit/payment/" + idAccount + " /" + sum, HttpMethod.GET, request, String.class);
        return response.getStatusCode();
    }

    public BigDecimal getUsersBalance() {
        String username = userService.getLoggedUser();
        HttpEntity request = new HttpEntity<>(restAuthenticationService.createHeadersWithAuthentication());
        ResponseEntity<Map<String, String>> response = restTemplate.exchange(restServiceURL + "accountinfo/" + username, HttpMethod.GET, request, typeStringRef);
        return new BigDecimal(getBodyValue(response));
    }

    public Map<Long, String> getEmails(String ids) {
        HttpEntity request = new HttpEntity<>(restAuthenticationService.createHeadersWithAuthentication());
        ParameterizedTypeReference<Map<Long, String>> typeRef = new ParameterizedTypeReference<Map<Long, String>>() {
        };
        return restTemplate.exchange(restServiceURL + "credit/emails?ids={remaining}", HttpMethod.POST, request, typeRef, ids).getBody();
    }
}
