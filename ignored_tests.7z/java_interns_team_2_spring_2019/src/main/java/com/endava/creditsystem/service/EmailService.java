package com.endava.creditsystem.service;

public interface EmailService {

    void sendApprovalEmailToClient(String clientEmail, Long idCredit);

    void sendRejectingEmailToClient(String clientEmail, Long idCredit);
}
