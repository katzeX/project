package com.endava.creditsystem.controller;

import com.endava.creditsystem.dto.PaymentDTO;
import com.endava.creditsystem.model.Notification;
import com.endava.creditsystem.service.NotificationService;
import com.endava.creditsystem.service.UserService;
import com.endava.creditsystem.service.UserServiceImpl;
import lombok.extern.log4j.Log4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@Log4j
public class TransactionController {

    @Autowired
    UserServiceImpl userServiceImpl;

    @Autowired
    private SimpMessagingTemplate simpMessagingTemplate;

    @Autowired
    private UserService userService;

    @Autowired
    private NotificationService notificationService;

    @GetMapping("/transaction")
    public String transactionForm(Model model) {
        model.addAttribute("paymentDTO", new PaymentDTO());

        return "transaction";
    }

    @GetMapping("/test")
    @ResponseBody
    public void test(){

        notificationService.save(new Notification("TEST", "xenia@gmail.com"));
        simpMessagingTemplate.convertAndSendToUser(userService.findByEmail("xenia@gmail.com").getNotificationToken(), "/notifications", "Test");

    }
}