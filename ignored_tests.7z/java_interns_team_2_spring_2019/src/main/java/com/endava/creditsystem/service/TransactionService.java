package com.endava.creditsystem.service;

import com.endava.creditsystem.dto.PaymentDTO;
import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.CreditStatus;
import com.endava.creditsystem.model.Transaction;
import com.endava.creditsystem.model.TransactionStatus;
import com.endava.creditsystem.model.TransactionType;
import com.endava.creditsystem.repository.CreditRepository;
import com.endava.creditsystem.repository.TransactionRepository;
import lombok.extern.log4j.Log4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Service
@Log4j
public class TransactionService {

    private BigDecimal sumForPayment;
    private BigDecimal sumAfterPayment = BigDecimal.ZERO;

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private CreditRepository creditRepository;

    @Autowired
    private RestApiService restApiService;

    @Autowired
    private WebSocketDistributeService webSocketDistributeService;

    @Autowired
    private UserService userService;

    public void saveAll(List<Transaction> transactionList) {
        transactionRepository.saveAll(transactionList);
    }

    private Transaction getMinTransaction(Long idCredit) {
        Transaction transaction = new Transaction();
        try {
            transaction = transactionRepository.findFirstByIdCreditAndTransactionTypeEqualsOrderByRateNumAsc(idCredit, TransactionType.COMMITMENT);
        } catch (NullPointerException e) {
            log.warn("No transactions with Transaction Type Commitment");
        }
        return transaction;
    }

    private List<Transaction> getCommitmentsByRate(Long idCredit) {
        List<Transaction> commitmentsByRate = new ArrayList<>();
        try {
            commitmentsByRate = transactionRepository.findAllByIdCreditOrderByPaymentTypeDesc(idCredit).
                    stream().
                    sorted(Comparator.comparingInt(Transaction::getRateNum)).
                    filter(x -> (x.getRateNum() == getMinTransaction(idCredit).getRateNum())).
                    collect(Collectors.toList());
        } catch (NullPointerException e) {
            
            log.warn( "No transactions by rate");
        }
        return commitmentsByRate;
    }

    private boolean checkBalance() {
        BigDecimal balance = restApiService.getUsersBalance();
        return balance.compareTo(sumForPayment) >= 0;
    }

    public TransactionStatus checkData(PaymentDTO paymentDTO, Long idAccount) {
        sumForPayment = paymentDTO.getSum();

        if (!checkBalance())
            return TransactionStatus.UNPAID;
        Transaction minTransaction = getMinTransaction(paymentDTO.getIdCredit());

        if (minTransaction == null) {
            setPaidCredit(paymentDTO.getIdCredit());
            return TransactionStatus.CLOSED;
        }

        List<Transaction> commitments = getCommitmentsByRate(paymentDTO.getIdCredit());

        int aux = 0;

        for (Transaction c : commitments) {
            aux += checkCommitment(paymentDTO.getSum(), c, idAccount);
        }

        if (restApiService.payForCredit(minTransaction.getIdAccount(), returnSumAfterPayment()) == HttpStatus.OK) {
            setPaidCredit(paymentDTO.getIdCredit());
            if (aux >= 3) {
                return TransactionStatus.INTEGRAL;
            } else if (aux >= 1) {
                return TransactionStatus.PARTIAL;
            }
        }
        return TransactionStatus.UNPAID;
    }

    private void setPaid(Transaction transaction, Long idAccount) {

        transaction.setIdAccount(idAccount);
        transaction.setPaidDate(LocalDateTime.now());
        transaction.setTransactionType(TransactionType.PAYMENT);
    }

    private boolean sendCommitment(Transaction commitment, Long idAccount) {
        if (payFor(commitment.getAmount())) {
            setPaid(commitment, idAccount);
            transactionRepository.save(commitment);
            return true;
        } else return false;
    }

    private boolean payFor(BigDecimal payFor) {
        sumForPayment = sumForPayment.subtract(payFor);
        return sumForPayment.compareTo(BigDecimal.ZERO) >= 0;
    }

    private int checkCommitment(BigDecimal sum, Transaction c, Long idAccount) {
        if (sendCommitment(c, idAccount)) {
            log.info("Able to pay for credit with id: " + +c.getIdCredit() + " Rate num: " + c.getRateNum() + " Payment Type: " + c.getPaymentType() + " Amount: " + c.getAmount());
            sumAfterPayment = sumAfterPayment.add(c.getAmount());
            return 1;
        } else {
            log.warn("Not enough money! Expected: " + c.getAmount() + "Given: " + sum);
            sumForPayment = sum;
        }
        return 0;
    }

    private void setPaidCredit(Long idCredit) {
        List<Transaction> paidTransactions = transactionRepository.findTransactionsByTransactionTypeEqualsAndIdCreditEquals(TransactionType.COMMITMENT, idCredit);
        Credit credit = creditRepository.findCreditByIdCredit(idCredit);

        if (paidTransactions.isEmpty()) {
            log.info("Credit " + idCredit + "IS CLOSED at" + LocalDate.now());
            credit.setStatus(CreditStatus.CLOSED);
            credit.setFinalDate(LocalDate.now());
            webSocketDistributeService.sendClosingCreditNotification(userService.getLoggedUser(), idCredit);
            creditRepository.saveAndFlush(credit);
        }
    }

    public List<Transaction> getAllTransactions(Long idCredit) {
        return transactionRepository.findAllByIdCreditAndPaidDateIsLessThanEqual(idCredit, LocalDateTime.now());
    }

    public BigDecimal getSumForPayment(Long idCredit) {
        List<Transaction> currentTransactions = getCommitmentsByRate(idCredit);

        if (currentTransactions.isEmpty()) {
            return null;
        } else {
            return currentTransactions
                    .stream()
                    .map(Transaction::getAmount)
                    .reduce(BigDecimal::add)
                    .get();
        }
    }

    public List<Credit> getAllCreditsByUser(Long idAccount) {
        List<Credit> credits = creditRepository.findCreditByIdAccountAndStatusEquals(idAccount, CreditStatus.ACTIVE);
        if (credits.isEmpty()) {
            return Collections.emptyList();
        } else return credits;
    }

    public BigDecimal returnSumAfterPayment() {
        return sumAfterPayment;
    }

    @Transactional
    public void deleteAllTransactionsByCreditId(Long idCredit) {
        try {
            transactionRepository.deleteAllByIdCreditEquals(idCredit);
            log.info("Transactions deleted successfully where credit id is: " + idCredit);
        } catch (Exception e) {
            log.warn("Failed to delete transactions by id credit: " + idCredit + " " + e.getCause());
        }
    }
}
