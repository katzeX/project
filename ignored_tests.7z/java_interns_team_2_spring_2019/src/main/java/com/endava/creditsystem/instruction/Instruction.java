package com.endava.creditsystem.instruction;


import com.endava.creditsystem.model.Transaction;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

public interface Instruction {
    String getId();

    String getDescription();

    List<Transaction> calculate(BigDecimal creditSum, int months, LocalDate referenceDate, BigDecimal value);
}
