package com.endava.creditsystem.instruction;

import com.endava.creditsystem.model.PaymentType;
import com.endava.creditsystem.model.Transaction;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class InterestInstruction implements Instruction {
    private String id = getClass().getName();
    private String description;

    @Override
    public List<Transaction> calculate(BigDecimal creditSum, int months, LocalDate referenceDate, BigDecimal value) {
        BigDecimal monthlyPayment = creditSum.divide(BigDecimal.valueOf(months), 2, RoundingMode.HALF_DOWN);
        List<Transaction> interestList = new ArrayList<>();

        LocalDate futureDate = referenceDate.plusMonths(1);

        for (int i = 0; i < months; i++) {
            Transaction transaction = new Transaction();
            transaction.setRateNum(i + 1);
            transaction.setAmount(creditSum.subtract(monthlyPayment.multiply(BigDecimal.valueOf(i)))
                    .multiply(value.divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP).divide(BigDecimal.valueOf(12), 7, RoundingMode.HALF_UP))
                    .setScale(2, RoundingMode.HALF_DOWN));
            transaction.setPaymentType(PaymentType.INTEREST_RATE);
            transaction.setPaymentDate(futureDate);
            futureDate = futureDate.plusMonths(1);
            interestList.add(transaction);
        }

        return interestList;
    }
}