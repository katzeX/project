package com.endava.creditsystem.model;

public enum PaymentType {
    CAPITAL,
    INTEREST_RATE,
    COMMISSION,
    FINE
}