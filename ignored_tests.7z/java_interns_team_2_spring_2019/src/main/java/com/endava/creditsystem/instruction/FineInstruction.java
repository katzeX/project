package com.endava.creditsystem.instruction;

import com.endava.creditsystem.model.PaymentType;
import com.endava.creditsystem.model.Transaction;
import com.endava.creditsystem.model.TransactionType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FineInstruction implements Instruction {
    private String id = getClass().getName();
    private String description;

    @Override
    public List<Transaction> calculate(BigDecimal creditSum, int months, LocalDate referenceDate, BigDecimal value) {
        BigDecimal fineAmount = creditSum.multiply(value.divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP));
        List<Transaction> fineList = new ArrayList<>();

        fineList.add(new Transaction(PaymentType.FINE, months, fineAmount, referenceDate, TransactionType.COMMITMENT));

        return fineList;
    }
}
