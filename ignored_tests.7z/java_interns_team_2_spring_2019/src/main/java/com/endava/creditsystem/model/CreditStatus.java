package com.endava.creditsystem.model;

public enum CreditStatus {
    ACTIVE,
    CLOSED,
    PENDING
}
