package com.endava.creditsystem.repository;

import com.endava.creditsystem.model.Role;
import com.endava.creditsystem.model.User;

import java.util.List;

public interface UserRepositoryForRoles {

    User getObjectForUpdate(Long id);

    List<Role> getRoles();

    void updateRole(long idPerson, int idRole);
}
