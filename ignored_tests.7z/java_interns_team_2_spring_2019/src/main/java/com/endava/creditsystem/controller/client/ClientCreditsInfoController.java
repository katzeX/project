package com.endava.creditsystem.controller.client;

import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.Product;
import com.endava.creditsystem.repository.ProductRepository;
import com.endava.creditsystem.service.ClientService;
import com.endava.creditsystem.service.UserService;
import lombok.extern.log4j.Log4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
@Log4j
public class ClientCreditsInfoController {
    @Autowired
    private UserService userService;

    @Autowired
    private ClientService clientService;
    @Autowired
    private ProductRepository productRepository;


    @GetMapping("/client/my-credits")
    public String findAllCredits(Model model) {

        try {
            model.addAttribute("creditsClient", clientService.getCreditsListByAccount(userService.getLoggedUser()));
            return "client/client_credits";
        } catch (Exception e) {
            log.info("This client don't have any credits");
            return "/client/clientPage";
        }


    }

    @GetMapping("/client/my-credits/transactions/{idCredit}")
    public String findAllCreditTransactions(Model model, @PathVariable Long idCredit) {
        List<Credit> creditList = clientService.getCreditsListByAccount(userService.getLoggedUser());
        for (Credit credit : creditList) {
            if (idCredit.equals(credit.getIdCredit())) {
                model.addAttribute("transactionsClient", clientService.getTransactionsListByCreditId(idCredit));
                Product product = productRepository.findProductByIdProduct(credit.getIdProduct());
                model.addAttribute("productCredit", product.getName());

                break;
            }
        }

        return "client/client_obligations";
    }
}
