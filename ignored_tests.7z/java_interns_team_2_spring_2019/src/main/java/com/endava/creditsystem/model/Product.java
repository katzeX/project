package com.endava.creditsystem.model;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;
import java.math.BigDecimal;
import java.util.List;


@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "credit_product")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_product")
    private Integer idProduct;

    @Column(name = "name")
    private String name;

    @Column(name = "description")
    private String description;

    @Column(name = "min_term")
    private int minTerm;

    @Column(name = "max_term")
    private int maxTerm;

    @Column(name = "min_sum")
    private BigDecimal minSum;

    @Column(name = "max_sum")
    private BigDecimal maxSum;

    @ToString.Exclude
    @JsonManagedReference
    @OneToMany(targetEntity = ProductInstruction.class, orphanRemoval = true, cascade = CascadeType.ALL)
    @JoinColumn(name = "id_product", referencedColumnName = "id_product", insertable = true, updatable = true)
    private List<ProductInstruction> productInstructions;

    @Transient
    private boolean selected;

    public Product(String name, String description, int minTerm, int maxTerm, BigDecimal minSum, BigDecimal maxSum, List<ProductInstruction> productInstructions) {
        this.name = name;
        this.description = description;
        this.minTerm = minTerm;
        this.maxTerm = maxTerm;
        this.minSum = minSum;
        this.maxSum = maxSum;
        this.productInstructions = productInstructions;
    }

    public Product(Integer idProduct, String name, String description, int minTerm, int maxTerm, BigDecimal minSum, BigDecimal maxSum, List<ProductInstruction> productInstructions) {
        this.idProduct = idProduct;
        this.name = name;
        this.description = description;
        this.minTerm = minTerm;
        this.maxTerm = maxTerm;
        this.minSum = minSum;
        this.maxSum = maxSum;
        this.productInstructions = productInstructions;
    }
}
