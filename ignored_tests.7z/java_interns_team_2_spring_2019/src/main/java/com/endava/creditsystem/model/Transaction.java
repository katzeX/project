package com.endava.creditsystem.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "credit_transaction")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_transaction")
    private Long idTransaction;

    @Column(name = "id_account")
    private Long idAccount;

    @Column(name = "id_credit")
    private Long idCredit;

    @Column(name = "payment_type")
    @Enumerated(EnumType.STRING)
    private PaymentType paymentType;

    @Column(name = "rate_num")
    private int rateNum;

    @Column(name = "amount")
    private BigDecimal amount;

    @Column(name = "payment_date")
    private LocalDate paymentDate;

    @Column(name = "paid_date")
    private LocalDateTime paidDate;

    @Column(name = "transaction_type")
    @Enumerated(EnumType.STRING)
    private TransactionType transactionType = TransactionType.COMMITMENT;

    public Transaction(Long idCredit, PaymentType paymentType, int rateNum, BigDecimal amount, TransactionType transactionType) {
        this.idCredit = idCredit;
        this.paymentType = paymentType;
        this.rateNum = rateNum;
        this.amount = amount;
        this.transactionType = transactionType;
    }

    public Transaction(Long idAccount, PaymentType paymentType, int rateNum, BigDecimal amount, LocalDate paymentDate) {
        this.idAccount = idAccount;
        this.paymentType = paymentType;
        this.rateNum = rateNum;
        this.amount = amount;
        this.paymentDate = paymentDate;
    }

    public Transaction(PaymentType paymentType, int rateNum, BigDecimal amount, LocalDate paymentDate, TransactionType transactionType) {
        this.paymentType = paymentType;
        this.rateNum = rateNum;
        this.amount = amount;
        this.paymentDate = paymentDate;
        this.transactionType = transactionType;
    }
}