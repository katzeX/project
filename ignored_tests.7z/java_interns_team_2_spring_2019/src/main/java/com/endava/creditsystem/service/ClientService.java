package com.endava.creditsystem.service;

import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.Transaction;
import com.endava.creditsystem.repository.CreditRepository;
import com.endava.creditsystem.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Service
public class ClientService {
    @Autowired
    private RestAuthenticationService restAuthenticationService;
    RestTemplate restTemplate = new RestTemplate();
    @Autowired
    private CreditRepository creditRepository;
    @Autowired
    private TransactionRepository transactionRepository;
    @Value("${rest.address}")
    private String REST_SERVICE_URI;

    public List<Credit> getCreditsListByAccount(String email) {
        HttpEntity request = new HttpEntity<>(restAuthenticationService.createHeadersWithAuthentication());
        ParameterizedTypeReference<Map<String, String>> typeRef = new ParameterizedTypeReference<Map<String, String>>() {
        };
        ResponseEntity<Map<String, String>> response = restTemplate.exchange(REST_SERVICE_URI + "account/" + email, HttpMethod.GET, request, typeRef);
        Long account = Long.parseLong(response.getBody().get("AccountID"));
        return creditRepository.findAllByIdAccount(account);
    }

    public List<Transaction> getTransactionsListByCreditId(Long id) {
        return transactionRepository.findAllByIdCreditOrderByPaymentDate(id);
    }
}
