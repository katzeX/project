package com.endava.creditsystem.repository;

import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;

@Repository
public class CustomerIMPL implements CustomerDAO {

    @PersistenceContext
    EntityManager entityManager;


    @Override
    public List<String> findAllEmails() {

        return entityManager.createQuery("select  c.email from User c").getResultList();

    }


}
