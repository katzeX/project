package com.endava.creditsystem.service;

import com.endava.creditsystem.model.Notification;
import com.endava.creditsystem.model.NotificationStatus;
import com.endava.creditsystem.repository.NotificationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificationService {

    @Autowired
    NotificationRepository notificationRepository;

    @Autowired
    UserService userService;

    public void save(Notification notification) {
        notificationRepository.save(notification);
    }

    public long getNotificationNumber() {
        return notificationRepository.findAllByNotificationStatusEqualsAndUserNameEquals(NotificationStatus.UNREAD, userService.getLoggedUser()).stream().count();
    }

    public void setNotificationStatus(){
        List<Notification> notifications = notificationRepository.findAllByUserNameEquals(userService.getLoggedUser());
        for (Notification notification: notifications
             ) {
            notification.setNotificationStatus(NotificationStatus.READ);
            save(notification);
        }
    }
}
