function getSelectedObject() {
    var idProduct = $('#idProduct option:selected').val();
    console.log(idProduct);
    $.ajax({
        url: '/client/products/' + idProduct,
        type: 'GET',
        success: function (response) {
            $('#amount').attr({
                max: response.maxSum,
                min: response.minSum
            });

            $('#period').attr({
                max: response.maxTerm,
                min: response.minTerm
            });
        }
    });
}