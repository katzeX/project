package com.endava.creditsystem.controller.admin;

import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.CreditStatus;
import com.endava.creditsystem.repository.ProductRepository;
import com.endava.creditsystem.service.EmailService;
import com.endava.creditsystem.service.RestApiService;
import com.endava.creditsystem.service.UserService;
import com.endava.creditsystem.service.ValidateCredit;
import lombok.extern.log4j.Log4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Map;

@Controller
@RequestMapping("/admin")
@Log4j
public class CreditApprovalController {
    @Autowired
    ValidateCredit validateCredit;
    @Autowired
    ProductRepository productRepository;
    @Autowired
    EmailService emailService;
    @Autowired
    UserService userService;
    @Autowired
    RestApiService restApiService;

    @GetMapping("/all-credits")
    public String findAllCredits(Model model) {
        model.addAttribute("creditsPending", validateCredit.getPendingCredits());
        model.addAttribute("creditsActive", validateCredit.getActiveCredits());
        model.addAttribute("creditsClosed", validateCredit.getClosedCredits());
        return "admin/credit-approval";
    }

    @GetMapping(value = "/deleteCredit/{idCredit}")
    public String deleteCredits(@PathVariable Long idCredit) {
        Credit credit = validateCredit.getCreditByID(idCredit);
        String account = String.valueOf(credit.getIdAccount());

        try {
            Map<Long, String> emails = restApiService.getEmails(account);
            for (Map.Entry<Long, String> entry : emails.entrySet()) {
                emailService.sendRejectingEmailToClient(entry.getValue(), credit.getIdCredit());
            }
        } catch (Exception e) {

            log.warn(e.getMessage() + " cause: " + e.getCause());

        } finally {
            validateCredit.delete(idCredit);
            log.info("Credit " + credit.getIdCredit() + " was deleted");
        }


        return "redirect:/admin/all-credits";
    }

    @RequestMapping("/credit-update/{id}")
    public String secondViewUpdate(Model model, @PathVariable Long id) {
        model.addAttribute("productName", validateCredit.getProductNameByIDProductFromCredit(id));
        model.addAttribute("credit", validateCredit.getCreditByID(id));
        model.addAttribute("client", validateCredit.getClientByCreditIDRest(id));
        return "/admin/credit-update";
    }

    @PostMapping(value = "/credit-update")
    public String updateCredit(@ModelAttribute Credit credit) {
        if (credit.getStatus().equals(CreditStatus.ACTIVE)) {
            //generate obligations
            validateCredit.saveAllTransactionsForActiveCredit(credit);
            //send mail of accepting the credit
            String account = String.valueOf(credit.getIdAccount());
            Map<Long, String> emails = restApiService.getEmails(account);
            if (emails.isEmpty()) {
                log.warn("No response on request for sent ids");
            }

            for (Map.Entry<Long, String> entry : emails.entrySet()) {
                emailService.sendApprovalEmailToClient(entry.getValue(), credit.getIdCredit());
            }
            //send money to account
            validateCredit.sendMoneyToAccountRest(credit.getIdAccount(), credit.getAmount());
        }
        validateCredit.update(credit);
        return "redirect:/admin/all-credits";
    }

}
