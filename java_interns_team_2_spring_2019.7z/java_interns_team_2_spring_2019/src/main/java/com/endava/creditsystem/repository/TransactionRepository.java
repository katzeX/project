package com.endava.creditsystem.repository;

import com.endava.creditsystem.model.PaymentType;
import com.endava.creditsystem.model.Transaction;
import com.endava.creditsystem.model.TransactionType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@RepositoryRestResource
public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    List<Transaction> findAllByIdCredit(Long idCredit);

    List<Transaction> findAllByIdCreditOrderByPaymentDate(Long idCredit);

    List<Transaction> findAllByIdCreditOrderByPaymentTypeDesc(Long idCredit);

    Transaction findFirstByIdCreditAndTransactionTypeEqualsOrderByRateNumAsc(Long idCredit, TransactionType transactionType);

    List<Transaction> findAllByTransactionTypeEquals(TransactionType transactionType);
    List<Transaction> findTransactionsByTransactionTypeEqualsAndIdCreditEquals(TransactionType transactionType, Long idCredit);

    List<Transaction> findAllByTransactionTypeEqualsAndPaymentDateLessThan(TransactionType transactionType, LocalDate date);

    Transaction findTransactionByIdCreditAndPaymentTypeEquals(Long idCredit, PaymentType paymentType);

    List<Transaction> findAllByIdCreditAndPaidDateIsLessThanEqual(Long idCredit, LocalDateTime localDateTime);

    List<Transaction> findTransactionsByPaymentDateEqualsAndTransactionTypeEquals(LocalDate localDate, TransactionType transactionType);

}
