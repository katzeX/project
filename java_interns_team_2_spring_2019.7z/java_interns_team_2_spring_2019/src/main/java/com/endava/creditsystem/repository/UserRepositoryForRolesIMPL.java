package com.endava.creditsystem.repository;

import com.endava.creditsystem.model.Role;
import com.endava.creditsystem.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;
import java.util.List;

@Repository
public class UserRepositoryForRolesIMPL implements UserRepositoryForRoles {

    @PersistenceContext
    EntityManager entityManager;
    @Autowired
    UserRepository userRepository;

    @Override
    public User getObjectForUpdate(Long id) {
        return userRepository.findUserById(id);
    }


    public List<Role> getRoles() {
        return entityManager.createQuery("SELECT  c from Role c").getResultList();
    }

    @Override
    @Transactional
    @org.springframework.data.jpa.repository.Query
    public void updateRole(long idPerson, int idRole) {
        Query query = entityManager.createNativeQuery("UPDATE users_roles SET role_id = ?0 where user_id = ?1 ");
        query.setParameter(0, idRole);
        query.setParameter(1, idPerson);
        query.executeUpdate();
    }
}
