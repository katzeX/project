package com.endava.creditsystem.repository;

import java.util.List;

public interface CustomerDAO {

    List<String> findAllEmails();

}
