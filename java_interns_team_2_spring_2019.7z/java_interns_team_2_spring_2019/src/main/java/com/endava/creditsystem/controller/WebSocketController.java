package com.endava.creditsystem.controller;

import com.endava.creditsystem.model.Notification;
import com.endava.creditsystem.model.NotificationStatus;
import com.endava.creditsystem.repository.NotificationRepository;
import com.endava.creditsystem.repository.UserRepository;
import com.endava.creditsystem.service.NotificationService;
import com.endava.creditsystem.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class WebSocketController {

    @Autowired
    UserRepository userRepository;

    @Autowired
    UserServiceImpl userService;

    @Autowired
    NotificationRepository notificationRepository;

    @Autowired
    NotificationService notificationService;

    @GetMapping("/api/account/token")
    public String getTokenByLoggedUser() {
        return userRepository.findByEmail(userService.getLoggedUser()).getNotificationToken();
    }

    @GetMapping("/client/api/account/notifications/all")
    public List<Notification> showNotifications() {
        return notificationRepository.findAllByNotificationStatusEqualsAndUserNameEquals(NotificationStatus.UNREAD, userService.getLoggedUser());
    }

    @GetMapping("/client/api/account/notifications")
    public long getNotificationNumber() {
        return notificationService.getNotificationNumber();
    }

    @GetMapping("/client/api/account/status")
    public ResponseEntity setNotificationStatusRead(){
        notificationService.setNotificationStatus();
        return new ResponseEntity(HttpStatus.OK);
    }
}
