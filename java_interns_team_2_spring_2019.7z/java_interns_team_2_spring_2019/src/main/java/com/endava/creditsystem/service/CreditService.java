package com.endava.creditsystem.service;

import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.repository.CreditRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CreditService {

    @Autowired
    private CreditRepository creditRepository;

    @Autowired
    private RestApiService restApiService;

    public void save(Credit credit) {
        credit.setIdAccount(restApiService.getCurrentIdAccount());
        creditRepository.save(credit);
    }
}
