package com.endava.creditsystem.repository;

import com.endava.creditsystem.model.Notification;
import com.endava.creditsystem.model.NotificationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification, Long> {
    List<Notification> findAllByNotificationStatusEqualsAndUserNameEquals(NotificationStatus notificationStatus, String userName);

    List<Notification> findAllByUserNameEquals(String userName);
}
