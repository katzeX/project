package com.endava.creditsystem.instruction;

import com.endava.creditsystem.model.PaymentType;
import com.endava.creditsystem.model.Transaction;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AnnuityCapitalInterestInstruction implements Instruction {
    private String id = getClass().getName();
    private String description;

    @Override
    public List<Transaction> calculate(BigDecimal creditSum, int months, LocalDate referenceDate, BigDecimal value) {
        BigDecimal interestRate = value.divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP).
                divide(BigDecimal.valueOf(12), 7, RoundingMode.HALF_UP);

        BigDecimal calculations = interestRate.divide(interestRate.add(BigDecimal.ONE).pow(months)
                .subtract(BigDecimal.ONE), 6, RoundingMode.HALF_UP);

        BigDecimal annuity = creditSum.multiply(interestRate.add(calculations))
                .setScale(2, RoundingMode.HALF_UP);

        LocalDate futureDate = referenceDate.plusMonths(1);

        List<Transaction> capitalInterestList = new ArrayList<>();
        BigDecimal balance = creditSum;
        BigDecimal interestSum, capitalSum;

        for (int i = 0; i < months; i++) {
            Transaction interestTransaction = new Transaction();
            Transaction capitalTransaction = new Transaction();
            interestTransaction.setRateNum(i + 1);
            capitalTransaction.setRateNum(i + 1);
            interestSum = balance.multiply(interestRate).setScale(2, RoundingMode.HALF_DOWN);
            interestTransaction.setAmount(interestSum);
            capitalSum = annuity.subtract(interestSum);
            capitalTransaction.setAmount(capitalSum);
            balance = balance.subtract(capitalSum);
            interestTransaction.setPaymentType(PaymentType.INTEREST_RATE);
            capitalTransaction.setPaymentType(PaymentType.CAPITAL);
            interestTransaction.setPaymentDate(futureDate);
            capitalTransaction.setPaymentDate(futureDate);
            futureDate = futureDate.plusMonths(1);
            capitalInterestList.add(interestTransaction);
            capitalInterestList.add(capitalTransaction);
        }

        BigDecimal sum = BigDecimal.ZERO;

        for (Transaction t : capitalInterestList) {
            if (t.getPaymentType().equals(PaymentType.CAPITAL)) {
                sum = sum.add(t.getAmount());
            }
        }

        BigDecimal lastCapital = capitalInterestList.get(months * 2 - 1).getAmount();
        capitalInterestList.get(months * 2 - 1).setAmount(lastCapital.add(creditSum).subtract(sum));

        return capitalInterestList;
    }
}
