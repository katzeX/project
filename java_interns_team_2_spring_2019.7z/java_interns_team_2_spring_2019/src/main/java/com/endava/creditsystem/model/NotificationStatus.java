package com.endava.creditsystem.model;

public enum NotificationStatus {
    READ,
    UNREAD
}
