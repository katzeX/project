package com.endava.creditsystem.service;

import com.endava.creditsystem.dto.GraphicDTO;
import com.endava.creditsystem.instruction.Instruction;
import com.endava.creditsystem.model.PaymentType;
import com.endava.creditsystem.model.Product;
import com.endava.creditsystem.model.ProductInstruction;
import com.endava.creditsystem.model.Transaction;
import com.endava.creditsystem.repository.ProductRepository;
import com.endava.creditsystem.utils.InstructionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private RestApiService restApiService;

    public void save(Product product) {
        productRepository.save(product);
    }

    public List<Product> findAll() {
        return productRepository.findAll();
    }

    public Product findProductByIdProduct(int id) {
        return productRepository.findProductByIdProduct(id);
    }

    public List<ProductInstruction> getProductInstructionsKeyList() {
        Map<String, Instruction> instructionMap = InstructionFactory.getInstructionMap();
        List<ProductInstruction> productInstructionList = new ArrayList<>();

        for (String key : instructionMap.keySet()) {
            ProductInstruction productInstruction = new ProductInstruction();
            productInstruction.setInstructionId(key);
            productInstructionList.add(productInstruction);
        }

        return productInstructionList;
    }

    public Product removeUnusedInstructions(Product product) {
        List<ProductInstruction> unusedInstructions = new ArrayList<>();
        for (ProductInstruction productInstruction : product.getProductInstructions()) {
            if (productInstruction.getValue() == null) {
                unusedInstructions.add(productInstruction);
            }
        }
        product.getProductInstructions().removeAll(unusedInstructions);

        return product;
    }

    private List<Transaction> calculate(BigDecimal creditAmount, Product product, Integer period) {
        List<Transaction> transactionList = new ArrayList<>();

        Map<String, Instruction> instructions = InstructionFactory.getInstructionMap();
        for (ProductInstruction productInstruction : product.getProductInstructions()) {
            String instructionName = productInstruction.getInstructionId();
            Instruction instruction = instructions.get(instructionName);
            List<Transaction> tempList = instruction.calculate(creditAmount, period, LocalDate.now(), productInstruction.getValue());
            transactionList.addAll(tempList);
        }
        return transactionList;
    }

    public BigDecimal getMaxPaymentPerMonth(List<Transaction> transactionList) {
        BigDecimal maxPaymentPerMonth = BigDecimal.ZERO;

        for (Transaction t : transactionList) {
            if (t.getRateNum() == 1) {
                maxPaymentPerMonth = maxPaymentPerMonth.add(t.getAmount());
            }
        }

        return maxPaymentPerMonth;
    }

    private List<Transaction> separateTransactionsByPaymentType(List<Transaction> transactionList, PaymentType paymentType) {
        List<Transaction> transactionsByPaymentType = new ArrayList<>();

        for (Transaction t : transactionList) {
            if (t.getPaymentType().equals(paymentType)) {
                transactionsByPaymentType.add(t);
            }
        }
        return transactionsByPaymentType;
    }

    public List<GraphicDTO> fillGraphic(BigDecimal creditAmount, Product product, Integer period) {
        List<GraphicDTO> graphic = new ArrayList<>();
        BigDecimal balance = creditAmount;
        List<Transaction> transactionList = calculate(creditAmount, product, period);
        List<Transaction> capitalList = separateTransactionsByPaymentType(transactionList, PaymentType.CAPITAL);
        List<Transaction> interestList = separateTransactionsByPaymentType(transactionList, PaymentType.INTEREST_RATE);
        List<Transaction> commissionList = separateTransactionsByPaymentType(transactionList, PaymentType.COMMISSION);

        for (Transaction t : capitalList) {
            GraphicDTO row = new GraphicDTO();
            row.setRateNum(t.getRateNum());
            row.setPaymentDate(t.getPaymentDate());
            row.setCapital(t.getAmount());
            row.setBalance(balance);
            balance = balance.subtract(t.getAmount());
            graphic.add(row);
        }

        int index = 0;
        for (GraphicDTO row : graphic) {
            row.setInterest(interestList.get(index).getAmount());
            index++;
        }

        index = 0;
        for (GraphicDTO row : graphic) {
            row.setCommission(commissionList.get(index).getAmount());
            index++;
        }

        return graphic;
    }

    public List<Transaction> getTransactions(Long creditId, BigDecimal creditAmount, Product product, Integer period) {
        List<Transaction> transactionList = calculate(creditAmount, product, period);
        Long idAccount = restApiService.getCurrentIdAccount();

        for (Transaction transaction : transactionList) {
            transaction.setIdCredit(creditId);
            transaction.setIdAccount(idAccount);
        }

        return transactionList;
    }
}