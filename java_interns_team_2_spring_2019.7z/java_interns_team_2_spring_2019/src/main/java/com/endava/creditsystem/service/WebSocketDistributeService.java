package com.endava.creditsystem.service;

import com.endava.creditsystem.model.Notification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Service;

@Service
public class WebSocketDistributeService {

    @Autowired
    private SimpMessagingTemplate simpMessagingTemplate;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private UserServiceImpl userService;

    public void sendRemainingNotification(String userName, int remainingDays) {
        String message = "There are " + remainingDays + " days left until payment. New notification";
        notificationService.save(new Notification(message, userName));
        simpMessagingTemplate.convertAndSendToUser(userService.findByEmail(userName).getNotificationToken(), "/notifications", message);
    }

    public void sendClosingCreditNotification(String userName, Long idCredit){
        String message = "Credit with id: " + idCredit + " is closed.";
        notificationService.save(new Notification(message, userName));
        simpMessagingTemplate.convertAndSendToUser(userService.findByEmail(userName).getNotificationToken(), "/notifications", message);
    }


}
