package com.endava.creditsystem.instruction;

import com.endava.creditsystem.model.PaymentType;
import com.endava.creditsystem.model.Transaction;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FixedCommissionInstruction implements Instruction {
    private String id = getClass().getName();
    private String description;

    @Override
    public List<Transaction> calculate(BigDecimal creditSum, int months, LocalDate referenceDate, BigDecimal value) {
        List<Transaction> commissionList = new ArrayList<>();

        LocalDate futureDate = referenceDate.plusMonths(1);

        for (Integer i = 0; i < months; i++) {
            Transaction transaction = new Transaction();
            transaction.setRateNum(i + 1);
            transaction.setAmount(value);
            transaction.setPaymentType(PaymentType.COMMISSION);
            transaction.setPaymentDate(futureDate);
            futureDate = futureDate.plusMonths(1);
            commissionList.add(transaction);
        }
        return commissionList;
    }
}
