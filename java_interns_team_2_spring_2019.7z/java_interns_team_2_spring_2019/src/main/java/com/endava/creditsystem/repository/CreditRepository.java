package com.endava.creditsystem.repository;

import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.CreditStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CreditRepository extends JpaRepository<Credit, Long> {
    Credit findCreditByIdCredit(Long idCredit);


    List<Credit> findCreditByIdAccountAndStatusEquals(Long idAccount, CreditStatus creditStatus);

    List<Credit> findAllByStatus(CreditStatus creditStatus);


    List<Credit> findAllByIdAccount(Long idAccount);

    @Override
    void deleteById(Long id);


}
