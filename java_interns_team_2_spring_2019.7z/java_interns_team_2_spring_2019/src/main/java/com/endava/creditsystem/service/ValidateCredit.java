package com.endava.creditsystem.service;

import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.CreditStatus;
import com.endava.creditsystem.model.CustomerPersonalData;
import com.endava.creditsystem.model.Product;
import com.endava.creditsystem.model.Transaction;
import com.endava.creditsystem.repository.CreditRepository;
import com.endava.creditsystem.repository.ProductRepository;
import lombok.extern.log4j.Log4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
@Log4j
public class ValidateCredit {
    @Autowired
    EntityManager entityManager;

    @Autowired
    private CreditRepository creditRepository;
    @Autowired
    private ProductRepository productRepository;
    @Autowired
    private TransactionService transactionService;
    @Autowired
    private ProductService productService;
    @Autowired
    private RestAuthenticationService restAuthenticationService;
    RestTemplate restTemplate = new RestTemplate();

    @Value("${rest.address}")
    private String REST_SERVICE_URI;

    public List<Credit> getPendingCredits() {
        return creditRepository.findAllByStatus(CreditStatus.PENDING);
    }

    public List<Credit> getClosedCredits() {
        return creditRepository.findAllByStatus(CreditStatus.CLOSED);
    }

    public List<Credit> getActiveCredits() {
        return creditRepository.findAllByStatus(CreditStatus.ACTIVE);
    }

    public void delete(Long id) {
        creditRepository.deleteById(id);
    }

    @Transactional
    public void update(Credit credit) {
        creditRepository.findCreditByIdCredit(credit.getIdCredit());
        creditRepository.save(credit);
    }

    public Credit getCreditByID(Long id) {
        return creditRepository.findCreditByIdCredit(id);
    }


    public String getProductNameByIDProductFromCredit(Long id) {
        Credit credit = creditRepository.findCreditByIdCredit(id);
        try {

            int idProduct = credit.getIdProduct();
            Product product = productRepository.findProductByIdProduct(idProduct);
            return product.getName();
        } catch (NullPointerException ex) {
            log.error("Id Product is null");
            return "";
        }
    }

    public CustomerPersonalData getClientByCreditIDRest(Long id) {
        Credit credit = creditRepository.findCreditByIdCredit(id);

        HttpEntity request = new HttpEntity<>(restAuthenticationService.createHeadersWithAuthentication());
        ParameterizedTypeReference<Map<String, String>> typeRef = new ParameterizedTypeReference<Map<String, String>>() {
        };
        CustomerPersonalData customerPersonalData = new CustomerPersonalData();
        try {
            long account = credit.getIdAccount();
            ResponseEntity<Map<String, String>> response = restTemplate.exchange(REST_SERVICE_URI + "customerinfo/" + account, HttpMethod.GET, request, typeRef);


            long idFromRest = Long.parseLong(Objects.requireNonNull(response.getBody()).get("IdCustomer"));
            double salaryFromRest = Double.parseDouble(response.getBody().get("salary"));
            customerPersonalData.setId(idFromRest);
            customerPersonalData.setName(response.getBody().get("name"));
            customerPersonalData.setSurname(response.getBody().get("surname"));
            customerPersonalData.setIdnp(response.getBody().get("idnp"));
            customerPersonalData.setSalary(salaryFromRest);

            return customerPersonalData;
        } catch (NullPointerException e) {
            log.warn("This client with credit id:[" + id + "] does not have an account");

            return customerPersonalData;
        }

    }


    public void sendMoneyToAccountRest(Long account, BigDecimal depositSum) {
        HttpEntity request = new HttpEntity<>(restAuthenticationService.createHeadersWithAuthentication());
        ParameterizedTypeReference<Map<String, String>> typeRef = new ParameterizedTypeReference<Map<String, String>>() {
        };
        ResponseEntity<Map<String, String>> response = restTemplate.exchange(REST_SERVICE_URI + "credit/deposit/" + account + "/" + depositSum, HttpMethod.GET, request, typeRef);
        log.info("Money was sent to Acc " + account + " Sum " + depositSum);
    }

    public void saveAllTransactionsForActiveCredit(Credit credit) {
        Product product = productService.findProductByIdProduct(credit.getIdProduct());
        List<Transaction> transactionList = productService.getTransactions(credit.getIdCredit(), credit.getAmount(), product, credit.getPeriod());
        try {
            transactionService.saveAll(transactionList);
            log.info("All obligations was generated and saved with success");
        } catch (NullPointerException ex) {
            log.error(ex.getMessage());
        }

    }
}
