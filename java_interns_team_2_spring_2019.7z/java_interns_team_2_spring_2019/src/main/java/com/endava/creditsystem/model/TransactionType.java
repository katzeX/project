package com.endava.creditsystem.model;

public enum TransactionType {
    COMMITMENT,
    PAYMENT
}