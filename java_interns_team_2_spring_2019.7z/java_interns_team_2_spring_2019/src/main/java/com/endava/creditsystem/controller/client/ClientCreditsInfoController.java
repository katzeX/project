package com.endava.creditsystem.controller.client;

import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.Product;
import com.endava.creditsystem.repository.ProductRepository;
import com.endava.creditsystem.service.ClientService;
import com.endava.creditsystem.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class ClientCreditsInfoController {
    @Autowired
    UserService userService;

    @Autowired
    ClientService clientService;
    @Autowired
    ProductRepository productRepository;


    @GetMapping("/client/my-credits")
    public String findAllCredits(Model model) {
        model.addAttribute("creditsClient", clientService.getCreditsListByAccount(userService.getLoggedUser()));
        return "client/client_credits";
    }

    @GetMapping("/client/my-credits/transactions/{idCredit}")
    public String findAllCreditTransactions(Model model, @PathVariable Long idCredit) {
        List<Credit> creditList = clientService.getCreditsListByAccount(userService.getLoggedUser());
        for (Credit credit : creditList) {
            if (idCredit.equals(credit.getIdCredit())) {
                model.addAttribute("transactionsClient", clientService.getTransactionsListByCreditId(idCredit));
                Product product = productRepository.findProductByIdProduct(credit.getIdProduct());
                model.addAttribute("productCredit", product.getName());

                break;
            }
        }

        return "client/client_obligations";
    }
}
