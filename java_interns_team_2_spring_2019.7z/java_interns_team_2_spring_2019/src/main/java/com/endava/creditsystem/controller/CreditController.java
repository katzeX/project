package com.endava.creditsystem.controller;

import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.CreditStatus;
import com.endava.creditsystem.model.Product;
import com.endava.creditsystem.model.Transaction;
import com.endava.creditsystem.service.CreditService;
import com.endava.creditsystem.service.EmailService;
import com.endava.creditsystem.service.ProductService;
import com.endava.creditsystem.service.RestApiService;
import com.endava.creditsystem.service.TransactionService;
import lombok.extern.log4j.Log4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Controller
@Log4j
public class CreditController {

    @Autowired
    private CreditService creditService;

    @Autowired
    private ProductService productService;

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private RestApiService restApiService;

    @Autowired
    private EmailService emailService;

    @GetMapping(value = "/client/request-credit")
    public String showCreditForm(Model model) {
        model.addAttribute("productsList", productService.findAll());
        model.addAttribute("credit", new Credit());

        return "/client/request_credit";
    }

    @PostMapping(value = "/client/request-credit")
    public String saveCredit(@ModelAttribute("credit") Credit credit) {
        Product product = productService.findProductByIdProduct(credit.getIdProduct());
        List<Transaction> transactionList = productService.getTransactions(credit.getIdCredit(), credit.getAmount(), product, credit.getPeriod());
        BigDecimal salary = restApiService.getSalaryOfCurrentUser();
        BigDecimal doubleMaxPaymentPerMonth = BigDecimal.valueOf(2).multiply(productService.getMaxPaymentPerMonth(transactionList));

        if (salary.compareTo(doubleMaxPaymentPerMonth) >= 0) {
            creditService.save(credit);
            transactionService.saveAll(transactionList);
            String account = String.valueOf(credit.getIdAccount());
            //send mail
            try {
                Map<Long, String> emails = restApiService.getEmails(account);
                for (Map.Entry<Long, String> entry : emails.entrySet()) {
                    emailService.sendApprovalEmailToClient(entry.getValue(), credit.getIdCredit());
                }
            } catch (Exception e) {
                log.warn(e.getMessage() + " cause: " + e.getCause());
            }
        } else {
            credit.setStatus(CreditStatus.PENDING);
            creditService.save(credit);
        }

        return "redirect:/client/show-products";
    }
}
