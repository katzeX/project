package com.endava.creditsystem.service;

import com.endava.creditsystem.model.Transaction;
import com.endava.creditsystem.model.TransactionType;
import com.endava.creditsystem.repository.TransactionRepository;
import com.endava.creditsystem.repository.UserRepository;
import lombok.extern.log4j.Log4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Log4j
@EnableScheduling
@Configuration
public class CronNotifications {

    private static final int COUNT_REMINDER_DAYS = 5;

    @Autowired
    TransactionRepository transactionRepository;

    @Autowired
    UserRepository userRepository;

    @Autowired
    RestAuthenticationService restAuthenticationService;

    @Autowired
    RestApiService restApiService;

    @Autowired
    WebSocketDistributeService webSocketDistributeService;

    public List<Long> checkTransactionsOnReminder() {
        return transactionRepository.findTransactionsByPaymentDateEqualsAndTransactionTypeEquals(LocalDate.now().plusDays(COUNT_REMINDER_DAYS), TransactionType.COMMITMENT).stream()
                .map(Transaction::getIdAccount).collect(Collectors.toList());
    }

    public void sendRequestForEmails() {

        String reminders = "";
        try {
            reminders = checkTransactionsOnReminder().stream()
                    .map(n -> n.toString())
                    .distinct()
                    .collect(Collectors.joining(","));

        } catch (NullPointerException e) {
            log.warn("Null pointer exception was generated on request to data base");
        }

        Map<Long, String> emails = restApiService.getEmails(reminders);
        if (emails.isEmpty()) {
            log.warn("No response on request for sent ids");
            return;
        }

        for (Map.Entry<Long, String> entry : emails.entrySet()) {
            webSocketDistributeService.sendRemainingNotification(entry.getValue(), COUNT_REMINDER_DAYS);
        }
    }

    @Scheduled(cron = "0 0 12 * * ?")
    public void cronJob() {
        sendRequestForEmails();
    }
}
