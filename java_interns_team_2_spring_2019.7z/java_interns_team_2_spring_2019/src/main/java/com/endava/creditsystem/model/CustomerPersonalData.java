package com.endava.creditsystem.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.transaction.Transactional;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Transactional
@Entity
@Table(name = "client")
public class CustomerPersonalData {
    @Id
    @Column(name = "id_customer")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    @Column(name = "idnp")
    @NotNull
    @Size(min = 13, max = 13, message = "IDNP must contain 13 numbers ex: 0123456789123")
    @Pattern(regexp = "[\\s]*[0-9]*[0-9]+", message = "IDNP must contain 13 numbers ex: 0123456789123")
    private String idnp;
    @Column(name = "name")
    @NotNull
    @Pattern(regexp = "^[a-zA-Z]*$")
    private String name;
    @Column(name = "surname")
    @NotNull
    @Pattern(regexp = "^[a-zA-Z]*$")
    private String surname;
    @Column(name = "salary")
    @NotNull
    @Min(1000)
    private double salary;

}
