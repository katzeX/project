package com.endava.creditsystem.instruction;


import com.endava.creditsystem.model.PaymentType;
import com.endava.creditsystem.model.Transaction;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class CapitalInstruction implements Instruction {
    private String id = getClass().getName();
    private String description;

    @Override
    public List<Transaction> calculate(BigDecimal creditSum, int months, LocalDate referenceDate, BigDecimal value) {
        BigDecimal monthlyPayment = creditSum.divide(BigDecimal.valueOf(months), 2, RoundingMode.HALF_DOWN);

        List<Transaction> capitalList = new ArrayList<>();

        LocalDate futureDate = referenceDate.plusMonths(1);

        for (Integer i = 0; i < months; i++) {
            Transaction transaction = new Transaction();
            transaction.setRateNum(i + 1);
            transaction.setAmount(monthlyPayment);
            transaction.setPaymentType(PaymentType.CAPITAL);
            transaction.setPaymentDate(futureDate);
            futureDate = futureDate.plusMonths(1);
            capitalList.add(transaction);
        }

        BigDecimal lastCapital = creditSum.subtract(monthlyPayment.multiply(BigDecimal.valueOf(months - 1)));
        capitalList.get(months - 1).setAmount(lastCapital);

        return capitalList;
    }
}
