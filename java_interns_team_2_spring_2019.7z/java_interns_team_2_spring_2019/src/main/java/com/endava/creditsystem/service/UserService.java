package com.endava.creditsystem.service;


import com.endava.creditsystem.model.Role;
import com.endava.creditsystem.model.User;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;
import java.util.Set;

public interface UserService extends UserDetailsService {

    List<User> findAll();

    User findByEmail(String email);

    String getLoggedUser();

    Set<String> getUserRoles();

    List<Role> getRoles();

    User getUserById(Long id);

    void updateRole(Long idPerson, int idRole);

}