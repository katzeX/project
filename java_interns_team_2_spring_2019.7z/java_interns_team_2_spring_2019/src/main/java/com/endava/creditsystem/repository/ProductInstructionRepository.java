package com.endava.creditsystem.repository;

import com.endava.creditsystem.model.Product;
import com.endava.creditsystem.model.ProductInstruction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductInstructionRepository extends JpaRepository<ProductInstruction, Integer> {

    List<ProductInstruction> findAllByProduct(Product product);
}
