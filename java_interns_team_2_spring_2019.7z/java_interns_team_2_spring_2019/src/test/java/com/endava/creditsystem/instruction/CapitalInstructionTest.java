package com.endava.creditsystem.instruction;

import com.endava.creditsystem.model.Transaction;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class CapitalInstructionTest {

    @Test
    public void calculate() {
        CapitalInstruction capitalInstruction = new CapitalInstruction();
        List<Transaction> capitalList = capitalInstruction.calculate(BigDecimal.valueOf(9500), 12, LocalDate.now(), BigDecimal.ZERO);

        assertNotNull(capitalList);
        assertEquals(12, capitalList.size());

        BigDecimal sum = BigDecimal.ZERO;
        for (Transaction t: capitalList) {
            sum = sum.add(t.getAmount());
        }

        assertEquals(9500, sum.intValue());
    }
}