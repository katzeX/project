package com.endava.creditsystem.instruction;

import com.endava.creditsystem.model.Transaction;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class InterestInstructionTest {

    @Test
    public void calculate() {
        InterestInstruction interestInstruction = new InterestInstruction();
        List<Transaction> interestList = interestInstruction.calculate(BigDecimal.valueOf(12000), 12, LocalDate.now(), BigDecimal.valueOf(10));

        assertNotNull(interestList);
        assertEquals(12, interestList.size());

        BigDecimal sum = BigDecimal.ZERO;
        for (Transaction t: interestList) {
            sum = sum.add(t.getAmount());
        }

        assertEquals(650, sum.intValue());
    }
}