package com.endava.creditsystem.controller;

import com.endava.creditsystem.controller.admin.CreditApprovalController;
import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.CreditStatus;
import com.endava.creditsystem.service.ValidateCredit;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.powermock.api.mockito.PowerMockito.when;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;


@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class CreditApprovalControllerTest {

    @InjectMocks
    private CreditApprovalControllerTest creditApprovalControllerTest;

    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext context;

    @MockBean
    private ValidateCredit validateCredit;



    @Test
    public void contextLoads() {
        assertThat(creditApprovalControllerTest).isNotNull();
        mockMvc = MockMvcBuilders
                .webAppContextSetup(context)
                .apply(springSecurity())
                .build();
    }

    @Before
    public void setup() {
        InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
        viewResolver.setPrefix("/resources/templates/");
        viewResolver.setSuffix(".html");

        mockMvc = MockMvcBuilders.standaloneSetup(new CreditApprovalController())
                .setViewResolvers(viewResolver)
                .build();

        MockitoAnnotations.initMocks(this);
    }

    @Ignore
    @Test
    public void shouldFindAllCredits() throws Exception{
        List<Credit> pendingCredits = new ArrayList<>();
        pendingCredits.add((new Credit(123L, 555555L, 1, new BigDecimal(5000), 6, LocalDate.now(), null, CreditStatus.PENDING)));

        List<Credit> activeCredits = new ArrayList<>();
        activeCredits.add((new Credit(123L, 555555L, 1, new BigDecimal(5000), 6, LocalDate.now(), null, CreditStatus.ACTIVE)));

        List<Credit> closedCredits = new ArrayList<>();
        closedCredits.add((new Credit(123L, 555555L, 1, new BigDecimal(5000), 6, LocalDate.now(), null, CreditStatus.CLOSED)));


        when(validateCredit.getPendingCredits()).thenReturn(pendingCredits);
        when(validateCredit.getActiveCredits()).thenReturn(activeCredits);
        when(validateCredit.getClosedCredits()).thenReturn(closedCredits);

        mockMvc.perform(get("/all-credits"))
                .andExpect(status().isOk())
                .andExpect(view().name("credit-approval"))
                .andExpect(model().attributeExists("creditsPending"))
                .andExpect(model().attributeExists("creditsActive"))
                .andExpect(model().attributeExists("creditsClosed"));
    }

}
