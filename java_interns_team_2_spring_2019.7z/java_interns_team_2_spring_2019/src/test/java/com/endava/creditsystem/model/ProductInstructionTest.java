package com.endava.creditsystem.model;

import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.web.client.AutoConfigureWebClient;
import org.springframework.test.context.junit4.SpringRunner;

import javax.persistence.EntityManager;

import java.util.List;

import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@AutoConfigureWebClient
public class ProductInstructionTest {

    @Autowired
    private EntityManager entityManager;

    @Ignore
    @Test
    public void testEntityManager() {
        assertNotNull(entityManager);
    }

    @Ignore
    @Test
    public void selectAllProducts() {
        List<Product> productList = entityManager.createQuery("from ProductInstruction pi join fetch pi.product" ).getResultList();
        assertNotNull(productList);
    }
}