package com.endava.creditsystem.instruction;

import com.endava.creditsystem.model.PaymentType;
import com.endava.creditsystem.model.Transaction;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class AnnuityCapitalInterestInstructionTest {

    @Test
    public void calculate() {
        AnnuityCapitalInterestInstruction annuityCapitalInterestInstruction = new AnnuityCapitalInterestInstruction();
        List<Transaction> capitalInterestList = annuityCapitalInterestInstruction.calculate(BigDecimal.valueOf(5000), 4, LocalDate.now(), BigDecimal.valueOf(24));

        assertNotNull(capitalInterestList);
        assertEquals(8, capitalInterestList.size());

        BigDecimal capitalSum = BigDecimal.ZERO;
        BigDecimal interestSum = BigDecimal.ZERO;

        for (Transaction t: capitalInterestList) {
            if (t.getPaymentType().equals(PaymentType.CAPITAL)) {
                capitalSum = capitalSum.add(t.getAmount());
            } else {
                interestSum = interestSum.add(t.getAmount());
            }
        }

        assertEquals(5000, capitalSum.intValue());
        assertEquals(BigDecimal.valueOf(252.48), interestSum);
    }
}