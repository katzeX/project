package com.endava.creditsystem.controller;

import com.endava.creditsystem.dto.PaymentDTO;
import com.endava.creditsystem.model.Credit;
import com.endava.creditsystem.model.CreditStatus;
import com.endava.creditsystem.model.PaymentType;
import com.endava.creditsystem.model.Transaction;
import com.endava.creditsystem.model.TransactionStatus;
import com.endava.creditsystem.model.TransactionType;
import com.endava.creditsystem.repository.TransactionRepository;
import com.endava.creditsystem.service.RestApiService;
import com.endava.creditsystem.service.TransactionService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.hamcrest.core.Is.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.BDDMockito.given;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest
public class TransactionRestControllerTest {

    @InjectMocks
    private TransactionRestController transactionRestController;

    @MockBean
    private TransactionService transactionService;

    private MockMvc mockMvc;

    @Autowired
    private WebApplicationContext context;

    @MockBean
    private RestApiService restApiService;

    @Autowired
    private TransactionRepository transactionRepository;

    Credit credit = new Credit(123L, 555555L, 1, new BigDecimal(5000), 6, LocalDate.now(), null, CreditStatus.ACTIVE);

    @Test
    public void contextLoads() {
        assertThat(transactionRestController).isNotNull();
        mockMvc = MockMvcBuilders
                .webAppContextSetup(context)
                .apply(springSecurity())
                .build();
    }


    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(transactionRestController).build();
    }

    public List<Transaction> getTransactions() {
        List<Transaction> commitments = new ArrayList<>();
        commitments.add(new Transaction(1L, 555555L, 123L, PaymentType.INTEREST_RATE, 1, new BigDecimal(100), LocalDate.now(), null, TransactionType.COMMITMENT));
        commitments.add(new Transaction(2L, 555555L, 123L, PaymentType.COMMISSION, 1, new BigDecimal(50), LocalDate.now(), null, TransactionType.COMMITMENT));
        commitments.add(new Transaction(3L, 555555L, 123L, PaymentType.CAPITAL, 1, new BigDecimal(1000), LocalDate.now(), null, TransactionType.PAYMENT));
        return commitments;
    }

    @Test
    public void shouldReturnAllTransaction() throws Exception {

        List<Transaction> transactions = getTransactions();

        given(transactionService.getAllTransactions(credit.getIdCredit())).willReturn(transactions);

        mockMvc.perform(get("/api/credit/" + credit.getIdCredit() + "/transactions")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(3)))
                .andExpect(jsonPath("$[0].idTransaction", is(1)));
    }

    @Test
    public void shouldReturnIdAccount() throws Exception {

        given(restApiService.getCurrentIdAccount()).willReturn(5555555L);

        mockMvc.perform(get("/api/account/idAccount")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", is(5555555)));
    }


    @Test
    public void shouldGetSumForPayment() throws Exception {

        given(transactionService.getSumForPayment(credit.getIdCredit())).willReturn(new BigDecimal(1050));

        mockMvc.perform(get("/api/credit/" + credit.getIdCredit() + "/transactions/payment/sum")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", is(1050)));
    }

    @Test
    public void shouldReturnAllCreditsByUser() throws Exception {

        List<Credit> credits = new ArrayList<>();
        credits.add(credit);

        given(transactionService.getAllCreditsByUser(5555555L)).willReturn(credits);

        mockMvc.perform(get("/api/credit/" + 5555555)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(1)))
                .andExpect(jsonPath("$[0].idCredit", is(credit.getIdCredit().intValue())));
    }

    @Test
    public void shouldReturnBalance() throws Exception {
        given(restApiService.getUsersBalance()).willReturn(new BigDecimal(10000));

        mockMvc.perform(get("/api/account/balance")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", is(10000)));
    }


    @Test
    public void shouldGetDataAndReturnHttpStatusAccepted() throws Exception{
        PaymentDTO paymentDTO = new PaymentDTO(123L, new BigDecimal(100));

        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(paymentDTO);

        when(transactionService.checkData(any(PaymentDTO.class), anyLong())).thenReturn(TransactionStatus.PARTIAL);

        mockMvc.perform(post("/transaction/" + 55555555)
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .content(json))
                .andExpect(status().isAccepted()).andReturn();
    }

    @Test
    public void shouldGetDataAndReturnHttpStatusIsOk() throws Exception{
        PaymentDTO paymentDTO = new PaymentDTO(123L, new BigDecimal(100));

        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(paymentDTO);

        when(transactionService.checkData(any(PaymentDTO.class), anyLong())).thenReturn(TransactionStatus.INTEGRAL);

        mockMvc.perform(post("/transaction/" + 55555555)
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .content(json))
                .andExpect(status().isOk()).andReturn();
    }

    @Test
    public void shouldGetDataAndReturnHttpStatusBadRequest() throws Exception{
        PaymentDTO paymentDTO = new PaymentDTO(123L, new BigDecimal(100));

        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(paymentDTO);

        when(transactionService.checkData(any(PaymentDTO.class), anyLong())).thenReturn(TransactionStatus.INTEGRAL);

        mockMvc.perform(post("/transaction/" + 55555555)
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .content(json))
                .andExpect(status().isOk()).andReturn();
    }

    @Test
    public void shouldGetDataAndReturnHttpStatusNotFound() throws Exception{
        PaymentDTO paymentDTO = new PaymentDTO(123L, new BigDecimal(100));

        ObjectMapper objectMapper = new ObjectMapper();
        String json = objectMapper.writeValueAsString(paymentDTO);

        when(transactionService.checkData(any(PaymentDTO.class), anyLong())).thenReturn(TransactionStatus.CLOSED);

        mockMvc.perform(post("/transaction/" + 55555555)
                .contentType(MediaType.APPLICATION_JSON_UTF8_VALUE)
                .content(json))
                .andExpect(status().isNotFound()).andReturn();
    }
}
