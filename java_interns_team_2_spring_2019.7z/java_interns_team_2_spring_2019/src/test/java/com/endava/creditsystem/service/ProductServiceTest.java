package com.endava.creditsystem.service;

import com.endava.creditsystem.instruction.Instruction;
import com.endava.creditsystem.model.Product;
import com.endava.creditsystem.model.ProductInstruction;
import com.endava.creditsystem.repository.ProductRepository;
import com.endava.creditsystem.utils.InstructionFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
public class ProductServiceTest {

    @InjectMocks
    private ProductService productService;

    @MockBean
    private ProductRepository productRepository;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void save() {
        productService.save(returnProduct());
        verify(productRepository, times(1)).save(anyObject());
    }

    @Test
    public void findAll() {
    }

    @Test
    public void whenValidIdProduct_thenProductShouldBeFound() {
        Product product = returnProduct();
        System.out.println(product.getIdProduct());
        when(productRepository.findProductByIdProduct(product.getIdProduct()))
                .thenReturn(product);

        Product found = productService.findProductByIdProduct(product.getIdProduct());

        assertEquals(found.getIdProduct(), product.getIdProduct());
    }

    @Test
    public void getProductInstructionsKeyList() {
    }

    @Test
    public void removeUnusedInstructions() {
    }

    @Test
    public void fillGraphic() {
    }

    private Product returnProduct() {
        Map<String, Instruction> instructionMap = InstructionFactory.getInstructionMap();
        List<ProductInstruction> productInstructionList = new ArrayList<>();

        for (String key : instructionMap.keySet()) {
            ProductInstruction productInstruction = new ProductInstruction();
            productInstruction.setInstructionId(key);
            productInstructionList.add(productInstruction);
        }

        return new Product(30, "summer", "description", 3, 12, BigDecimal.valueOf(10000), BigDecimal.valueOf(15000),  productInstructionList);
    }
}