package com.endava.banking.model;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.*;

public class UserTest {

    @Mock
    User u1;

    @Mock
    User u2;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        String fname = "Ftest";
        String lname = "Ltest";
        String email = "test.test@test.com";
        String password = "testpass";
        u1 = new User();
        u2 = new User(fname,lname,email,password);
    }

    @Test
    public void getFirstName() {
        assertTrue(u2.getFirstName().equals("Ftest"));
    }

    @Test
    public void setFirstName() {
        u2.setFirstName("Ftext");
        assertTrue(u2.getFirstName().equals("Ftext"));
    }

    @Test
    public void getLastName() {
        assertTrue(u2.getLastName().equals("Ltest"));
    }

    @Test
    public void setLastName() {
        u2.setLastName("Ltext");
        assertTrue(u2.getLastName().equals("Ltext"));
    }

    @Test
    public void getEmail() {
        assertTrue(u2.getEmail().equals("test.test@test.com"));
    }

    @Test
    public void setEmail() {
        u2.setEmail("text.text@text.com");
        assertTrue(u2.getEmail().equals("text.text@text.com"));
    }

    @Test
    public void getPassword() {
        assertTrue(u2.getPassword().equals("testpass"));
    }

    @Test
    public void setPassword() {
        u2.setPassword("textpass");
        assertTrue(u2.getPassword().equals("textpass"));
    }

    @Test
    public void toString1() {
        u2.setId(1L);
        assertTrue(u2.toString().equals("User{" +
                "id=" + u2.getId() +
                ", firstName='" + u2.getFirstName() + '\'' +
                ", lastName='" + u2.getLastName() + '\'' +
                ", email='" + u2.getEmail() + '\'' +
                ", password='" + "*********" + '\'' +
                ", roles=" + u2.getRoles() +
                '}'));
    }
}