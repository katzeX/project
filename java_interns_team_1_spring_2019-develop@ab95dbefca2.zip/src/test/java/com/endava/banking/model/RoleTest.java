package com.endava.banking.model;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.*;

public class RoleTest {

    @Mock
    Role r1;

    @Mock
    Role r2;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        r1 = new Role();
        String name = "Test";
        r2 = new Role(name);
    }

    @Test
    public void getName() {
        assertTrue(r2.getName().equals("Test"));
    }

    @Test
    public void setName() {
        r2.setName("Text");
        assertTrue(r2.getName().equals("Text"));
    }

    @Test
    public void toString1() {
        assertTrue(r2.toString().equals("Role{" +
            "id=" + r2.getId() +
                    ", name='" + r2.getName() + '\'' +
                    '}'));
    }
}