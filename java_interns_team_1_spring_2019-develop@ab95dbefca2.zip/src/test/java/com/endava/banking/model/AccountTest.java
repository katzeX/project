package com.endava.banking.model;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.*;

public class AccountTest {

    @InjectMocks
    Account test = new Account();

    @Mock
    Account account;

    @Mock
    Account account1;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        long id_account = 11111111L;
        int id_customer = 25;
        float balance = 250000F;
        int account_type = 1;
        account = new Account();
        account1 = new Account(id_account,id_customer,balance,account_type);
    }

    @Test
    public void getId_account() {
        assertTrue(account1.getIdAccount()==11111111L);
    }

    @Test
    public void setId_account() {
        test.setIdAccount(22211122L);
        assertTrue(test.getIdAccount()==22211122L);
    }

    @Test
    public void getId_customer() {
        assertTrue(account1.getIdCustomer()==25);
    }

    @Test
    public void setId_customer() {
        test.setIdCustomer(20);
        assertTrue(test.getIdCustomer()==20);
    }

    @Test
    public void getBalance() {
        assertTrue(account1.getBalance()==250000F);
    }

    @Test
    public void setBalance() {
        test.setBalance(20000F);
        assertTrue(test.getBalance()==20000F);
    }

    @Test
    public void getAccount_type() {
        assertTrue(account1.getAccountType()==1);
    }

    @Test
    public void setAccount_type() {
        test.setAccountType(2);
        assertTrue(test.getAccountType()==2);
    }
}