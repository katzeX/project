package com.endava.banking.model;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import java.sql.Timestamp;

import static org.junit.Assert.assertTrue;

public class TransactionsTest {

    @InjectMocks
    Transactions transactions = new Transactions();

    @Mock
    Transactions t1;

    @Mock
    Transactions t2;

    @Mock
    Timestamp date;

    @Before
    public void setUp() throws Exception {
        t1 = new Transactions();
        long from_account = 11111111L;
        long to_account = 22222222L;
        float amount = 25000F;
        java.util.Date util = new java.util.Date();
        date = new Timestamp(util.getTime());
        PaymentStatus status = PaymentStatus.DONE;
        t2 = new Transactions(from_account,to_account,amount,date,status);
    }

    @Test
    public void getFrom_account() {
        assertTrue(t2.getFromAccount()==11111111L);
    }

    @Test
    public void setFrom_account() {
        transactions.setFromAccount(99966633L);
        assertTrue(transactions.getFromAccount()==99966633L);
    }

    @Test
    public void getTo_account() {
        assertTrue(t2.getToAccount()==22222222L);
    }

    @Test
    public void setTo_account() {
        transactions.setToAccount(33666999L);
        assertTrue(transactions.getToAccount()==33666999L);
    }

    @Test
    public void getAmount() {
        assertTrue(t2.getAmount()==25000F);
    }

    @Test
    public void setAmount() {
        transactions.setAmount(15000F);
        assertTrue(transactions.getAmount()==15000F);
    }

    @Test
    public void getDate() {
        assertTrue(t2.getDate()==date);
    }

    @Test
    public void setDate() {
        transactions.setDate(date);
        assertTrue(transactions.getDate()==date);
    }

    @Test
    public void getStatus() {
        assertTrue(t2.getStatus()==PaymentStatus.DONE);
    }

    @Test
    public void setStatus() {
        t2.setStatus(PaymentStatus.REJECTED);
        assertTrue(t2.getStatus()==PaymentStatus.REJECTED);
    }
}