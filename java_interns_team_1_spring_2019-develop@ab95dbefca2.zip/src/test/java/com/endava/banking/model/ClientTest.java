package com.endava.banking.model;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.Assert.*;

public class ClientTest {

    @Mock
    Client c1;

    @Mock
    Client c2;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        String name = "Test";
        String surname = "Surtest";
        float salary = 15000F;
        int idnp = 123123123;
        c1 = new Client();
        c2 = new Client(name,surname,salary,idnp);
    }

    @Test
    public void getIdCustomer() {
    }

    @Test
    public void setIdCustomer() {
    }

    @Test
    public void getName() {
        assertTrue(c2.getName().equals("Test"));
    }

    @Test
    public void setName() {
        c2.setName("Aux");
        assertTrue(c2.getName().equals("Aux"));
    }

    @Test
    public void getSurname() {
        assertTrue(c2.getSurname().equals("Surtest"));
    }

    @Test
    public void setSurname() {
        c2.setSurname("Suraux");
        assertTrue(c2.getSurname().equals("Suraux"));
    }

    @Test
    public void getSalary() {
        assertTrue(c2.getSalary()==15000F);
    }

    @Test
    public void setSalary() {
        c2.setSalary(25000F);
        assertTrue(c2.getSalary()==25000F);
    }

    @Test
    public void getIdnp() {
        assertTrue(c2.getIdnp()==123123123);
    }

    @Test
    public void setIdnp() {
        c2.setIdnp(987987987);
        assertTrue(c2.getIdnp()==987987987);
    }
}