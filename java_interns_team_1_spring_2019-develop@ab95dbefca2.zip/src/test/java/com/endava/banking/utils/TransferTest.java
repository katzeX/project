package com.endava.banking.utils;

import com.endava.banking.model.*;
import com.endava.banking.repository.AccountRepository;
import com.endava.banking.service.AccountService;
import com.endava.banking.service.ClientService;
import com.endava.banking.service.TransactionService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import static com.endava.banking.model.AccountType.INDIVIDUAL;
import static org.junit.Assert.*;
import static org.mockito.ArgumentMatchers.anyObject;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class TransferTest {

    @InjectMocks
    Transfer transfer;

    @Mock
    TransactionService serviceTransaction;

    @Mock
    Account account;

    @Mock
    Account account2;

    @Mock
    Transactions transactions;

    @Mock
    AccountService serviceAccount;

    @Mock
    ClientService clientService;

    @Mock
    AccountRepository accountRepository;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        Date utilDate = new Date();
        Timestamp sqlDate = new java.sql.Timestamp(utilDate.getTime());
        account = new Account(12345678L, 60, 16000F, 1);
        account2 = new Account(87654321L,70,25000F,1);
        transactions = new Transactions(12345678L,87654321L,5000F,sqlDate, PaymentStatus.PENDING);
    }

    @Test
    public void transfer() {
        when(serviceAccount.getByID(transactions.getFromAccount())).thenReturn(account);
        when(serviceAccount.getByID(transactions.getToAccount())).thenReturn(account2);
        transfer.transfer(12345678L,87654321L,5000F);
        verify(serviceAccount).getByID(transactions.getFromAccount());
        verify(serviceAccount).getByID(transactions.getToAccount());
        assertEquals(account,serviceAccount.getByID(transactions.getFromAccount()));
        assertEquals(account2,serviceAccount.getByID(transactions.getToAccount()));
        assertEquals(11000F, account.getBalance(), 0.0);
        assertEquals(30000F, account2.getBalance(), 0.0);
    }

    @Test
    public void transactions() {
        transfer.transactions(transactions.getFromAccount(),transactions.getToAccount(),transactions.getAmount(),transactions.getDate(),transactions.getStatus());
        verify(serviceTransaction).add(anyObject());
    }

    @Test
    public void salary() {
        List<Account> accountList = serviceAccount.getAll();
        List<Client> clientList = clientService.getAllClients();
        assertFalse(accountList==null);
        assertFalse(clientList==null);
        when(clientService.getAllClients()).thenReturn(clientList);
        when(serviceAccount.getAll()).thenReturn(accountList);
        transfer.salary();
        for (Account a:accountList) {
            for (Client c:clientList) {
                if (a.getIdCustomer() == c.getIdCustomer() && a.getAccountType() == 1){
                    assertEquals(a.getIdCustomer(), c.getIdCustomer());
                    assertEquals(1, a.getAccountType());
                    assertEquals(a.getBalance(), a.getBalance() + c.getSalary(), 0.0);
                    verify(accountRepository).save(a);
                }
            }
        }
    }
}