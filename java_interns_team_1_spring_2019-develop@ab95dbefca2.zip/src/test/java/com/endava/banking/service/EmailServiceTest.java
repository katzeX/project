package com.endava.banking.service;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

@SpringBootTest
public class EmailServiceTest {

    @Mock
    EmailService emailService;

    @Mock
    JavaMailSender mailSender;

    SimpleMailMessage simpleMailMessage;


    @Before
    public void before() {
        MockitoAnnotations.initMocks(this);

        simpleMailMessage = new SimpleMailMessage();
        simpleMailMessage.setFrom("test");
        simpleMailMessage.setTo("test");
        simpleMailMessage.setSubject("test");
    }

    @Test
    public void sendEmail() {
        emailService.sendEmail(simpleMailMessage);
        Mockito.verify(emailService).sendEmail(simpleMailMessage);
        mailSender.send(simpleMailMessage);
        Mockito.verify(mailSender).send(simpleMailMessage);
    }
}