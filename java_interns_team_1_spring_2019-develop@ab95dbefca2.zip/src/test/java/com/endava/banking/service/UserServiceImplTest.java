package com.endava.banking.service;

import com.endava.banking.controller.dto.UserRegistrationDto;
import com.endava.banking.model.User;
import com.endava.banking.model.UserStatus;
import com.endava.banking.model.VerificationToken;
import com.endava.banking.repository.AccountRepository;
import com.endava.banking.repository.UserRepository;
import com.endava.banking.repository.VerificationTokenRepository;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import static org.mockito.Mockito.*;


@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@SpringBootTest
public class UserServiceImplTest {

    @InjectMocks
    UserServiceImpl userService;


    @Mock
    UserRepository userRepository;

    @Mock
    VerificationTokenRepository verificationTokenRepository;

    @Mock
    BCryptPasswordEncoder bCryptPasswordEncoder;

    @Mock
    private User theUser;

    @InjectMocks
    private AccountService accountService;

    @Mock
    private AccountRepository accountRepository;

    @Mock
    private UserRegistrationDto userRegistrationDto;


    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        theUser = new User("John", "Smith", "john.smith@john.com", "test123");
        userRegistrationDto = new UserRegistrationDto();
        userRegistrationDto.setEmail(theUser.getEmail());
        userRegistrationDto.setFirstName(theUser.getFirstName());
        userRegistrationDto.setLastName(theUser.getLastName());
        userRegistrationDto.setEmail(theUser.getEmail());
        userRegistrationDto.setConfirmEmail(theUser.getEmail());
        userRegistrationDto.setPassword(theUser.getPassword());
        userRegistrationDto.setConfirmPassword(theUser.getPassword());
        theUser.setPassword(bCryptPasswordEncoder.encode(theUser.getPassword()));

    }

    @Test
    public void findByEmail() {
        userService.findByEmail(anyString());
        verify(userRepository).findByEmail(anyString());
    }

    @Test
    public void save() {

        when(userRepository.findByEmail(theUser.getEmail())).thenReturn(theUser);

        Assert.assertEquals(userService.findByEmail(theUser.getEmail()), theUser);

    }

    @Test
    public void loadUserByUsername() {
        userService.findByEmail(anyString());
        verify(userRepository).findByEmail(anyString());
    }


    @Test
    public void findAll() {
        userService.findAll();
        verify(userRepository).findAllUsersAndRole();
    }

    @Test
    public void getById() {
        userService.getById(anyLong());
        verify(userRepository).getOne(anyLong());
    }

    @Test
    public void updateStatus() {
        userService.updateStatus(UserStatus.ACTIVE, 1L);
        verify(userRepository).updateStatus(UserStatus.ACTIVE, 1L);
    }

    @Test
    public void updateRole() {
        userService.updateRole(2, 1L);
        verify(userRepository).updateRole(2, 1L);
    }

    @Test
    public void createVerificationToken() {
        userService.createVerificationToken(new User(), "test");
        verify(verificationTokenRepository).save(any(VerificationToken.class));
    }


    @Test
    public void getVerificationToken() {
        userService.getVerificationToken(anyString());
        verify(verificationTokenRepository).findByToken(anyString());
    }

    @Test
    public void assighnRole() {
        userService.assighnRole(1L, 1L);
        verify(userRepository).assignRole(1L, 1L);
    }

    @Test
    public void deleteUserById() {
        userService.deleteUserById(1L);
        verify(userRepository).deleteUserById(1L);
    }

    @Test
    public void deleteVerificationTokenByUserId() {
        userService.deleteVerificationTokenByUserId(1L);
        verify(verificationTokenRepository).deleteToeknByUserId(1L);
    }

    @Test
    public void deleteUserRolesById() {
        userService.deleteUserById(1L);
        verify(userRepository, Mockito.times(1)).deleteUserById(1L);
    }

    @Test
    public void deleteUserAfterLinkExpired() {
        userService.deleteUserAfterLinkExpired(1L);
        verify(userRepository).deleteUserById(1L);
        verify(verificationTokenRepository).deleteToeknByUserId(1L);
        verify(userRepository).deleteUserById(1L);
    }

    @Test
    public void dropOldTokens() {
        userService.dropOldTokens();
        verify(verificationTokenRepository, Mockito.times(1)).findAll();
    }

}