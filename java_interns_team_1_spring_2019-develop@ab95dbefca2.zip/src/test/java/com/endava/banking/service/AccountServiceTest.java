package com.endava.banking.service;

import com.endava.banking.model.Account;
import com.endava.banking.repository.AccountRepository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@DataJpaTest()
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class AccountServiceTest {

    @InjectMocks
    AccountService accountService;

    @Mock
    private AccountRepository accountRepository;

    private Account account;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        account = new Account(11111112, 1, 30000, 1);
    }

    @Test
    public void getAll() {
        accountService.getAll();
        verify(accountRepository).findAll();
    }

    @Test
    public void getByID() {
        long id = 3000;
        accountService.getByID(id);
        verify(accountRepository).getOne(id);
    }

    @Test
    public void existsAccountByIdAccount() {
        long id = 3000;
        accountService.existsAccountByIdAccount(id);
        verify(accountRepository).existsAccountByIdAccount(id);
    }

    @Test
    public void getAccountByIdCustomerAndAccountType(){
        when(accountRepository.getAccountByIdCustomerAndAccountType(account.getIdCustomer(),account.getAccountType())).thenReturn(account);
        long acc = accountService.getAccountByIdCustomerAndAccountType(account.getIdCustomer(),account.getAccountType()).getIdAccount();
        assertTrue(11111112==acc);
    }

    @Test
    public void getAccountByIdCustomer(){
        long id = 3000;
        accountService.getAccountByIdCustomer(id);
        verify(accountRepository).getAccountByIdCustomer(id);
    }

    @Test
    public void save() {
        accountService.save(account);
        verify(accountRepository).save(account);
    }

}