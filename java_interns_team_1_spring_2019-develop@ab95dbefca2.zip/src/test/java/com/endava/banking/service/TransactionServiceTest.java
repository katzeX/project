package com.endava.banking.service;

import com.endava.banking.controller.dto.UserTransactionsDto;
import com.endava.banking.model.Account;
import com.endava.banking.model.PaymentStatus;
import com.endava.banking.model.ServicesProvider;
import com.endava.banking.model.Transactions;
import com.endava.banking.repository.AccountRepository;
import com.endava.banking.repository.TransactionsRepository;
import com.endava.banking.utils.Transfer;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.ArrayList;
import java.util.Date;
import java.sql.Timestamp;
import java.util.List;

import static org.hamcrest.CoreMatchers.is;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;

@DataJpaTest()
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class TransactionServiceTest {

    @InjectMocks
    TransactionService transactionService;

    @Mock
    TransactionsRepository transactionsRepository;

    @Mock
    AccountRepository accountRepository;

    @Mock
    Transfer transfer;

    @Mock
    Transactions transactions;

    @Mock
    private Date utilDate;
    @Mock
    private Timestamp ts;
    private Transactions tr1;
    private Transactions tr2;
    private List<Transactions> trList = new ArrayList<>();
    private Account account;

    @Before
    public void setUp() throws Exception {
        MockitoAnnotations.initMocks(this);
        utilDate = new Date();
        ts = new Timestamp(utilDate.getTime());
        transactions = new Transactions(11111111L, 22222222L, 12000F, ts, PaymentStatus.PENDING);
        tr1 = new Transactions(33333333L, 44444444L, 15000F, ts, PaymentStatus.PENDING);
        tr2 = new Transactions(33333333L, 44444444L, 11000F, ts, PaymentStatus.PENDING);
        trList.add(transactions);
        trList.add(tr1);
        trList.add(tr2);
        account = new Account(33333333L, 50, 2000000F, 1);
    }

    @Test
    public void getAll() {
        transactionService.getAll();
        verify(transactionsRepository).findAll();
    }

    @Test
    public void add() {
        transactionService.add(transactions);
        verify(transactionsRepository).save(transactions);
    }

    @Test
    public void remove() {
        long id = 13;
        transactionService.remove(id);
        verify(transactionsRepository).deleteById(id);
    }

    @Test
    public void getByID() {
        long id = 13;
        transactionService.getByID(id);
        verify(transactionsRepository).getOne(id);
    }

    @Ignore
    @Test
    public void transfer() {
        long from_account = 11111111L;
        long to_account = 22222222L;
        float amount = 10000F;
        PaymentStatus status;
        when(accountRepository.getOne(from_account)).thenReturn(account);
        transactionService.transfer(from_account,to_account,amount);
        if (account.getBalance() >= amount && amount <= 10000F) {
            tr1.setStatus(PaymentStatus.DONE);
            status=PaymentStatus.DONE;
            assertEquals(PaymentStatus.DONE, tr1.getStatus());
            verify(transfer).transfer(from_account,to_account,amount);
        } else if (account.getBalance() >= amount && amount > 10000F) {
            tr1.setStatus(PaymentStatus.PENDING);
            status=PaymentStatus.PENDING;
            assertNotEquals(PaymentStatus.PENDING, tr1.getStatus());
        } else{ tr1.setStatus(PaymentStatus.REJECTED); status=PaymentStatus.REJECTED; assertNotEquals(PaymentStatus.REJECTED, tr1.getStatus());
        }
        verify(transfer).transactions(from_account,to_account,amount,ts,status);
    }

    @Test
    public void getAllPending() {
        when(transactionService.getAll()).thenReturn(trList);
        List<Transactions> aux = new ArrayList<>();
        for (Transactions tr : trList) {
            if (tr.getStatus().compareTo(PaymentStatus.PENDING)==1) {
                aux.add(tr);
            }
        }
        assertThat(transactionService.getAllPending(), is(aux));
    }

    @Test
    public void approvePending() {
        when(accountRepository.getOne(11111111L)).thenReturn(account);
        transactionService.approvePending(transactions);
        verify(transfer, times(1)).transfer(11111111L, 22222222L, 12000F);
        assertTrue(transactions.getStatus() == PaymentStatus.DONE);
        verify(transactionsRepository).save(transactions);
    }

    @Test
    public void declinePending() {
        transactionService.declinePending(transactions);
        assertTrue(transactions.getStatus()==PaymentStatus.REJECTED);
        verify(transactionsRepository).save(transactions);
    }

    @Test
    public void retrieveTransactionsToAsDTO() {
        long id =13;
        transactionService.retrieveTransactionsToAsDTO(id);
        verify(transactionsRepository).retrieveTransactionsToAsDTO(id);

    }

    @Test
    public void retrieveTransactionsFromAsDTO(){
        long id = 13;
        transactionService.retrieveTransactionsFromAsDTO(id);
        verify(transactionsRepository).retrieveTransactionsFromAsDTO(id);
    }

    @Ignore
    @Test
    public void getTransactionsAmount(){
        long id =13;
        transactionService.getTransactionsAmount(id);
        verify(transactionsRepository,Mockito.times(2)).getTransactionsAmount(id);
    }
    @Ignore
    @Test
    public void getComunalPayments(){
        long id =13;
        transactionService.getComunalPayments(id);
        verify(transactionsRepository, Mockito.times(2)).getComunalPayments(id);
    }
    @Ignore
    @Test
    public void getItPayments(){
        long id=13;
        transactionService.getItPayments(id);
        verify(transactionsRepository, Mockito.times(2)).getItPayments(id);
    }

}