package com.endava.banking.service;

import com.endava.banking.model.Account;
import com.endava.banking.model.Company;
import com.endava.banking.model.ServicesProvider;
import com.endava.banking.repository.AccountRepository;
import com.endava.banking.repository.CompanyRepository;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import static com.endava.banking.model.ServicesProvider.IT;
import static org.mockito.Mockito.verify;


@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class CompanyServiceTest {


    @InjectMocks
    CompanyService companyService = new CompanyService();

    @InjectMocks
    AccountService accountService = new AccountService();

    @Mock
    CompanyRepository companyRepositoryInterface;

    @Mock
    AccountRepository accountRepository;

    @Mock
    Account account;

    private Company theCompany;

    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        theCompany = new Company("test", IT);
    }


    @Test
    public void findAll() {

        companyService.findAll();
        verify(companyRepositoryInterface).findAll();

    }

    @Test
    public void getById() {
        companyService.getById(1L);
        verify(companyRepositoryInterface).getOne(1L);
    }

    @Test
    public void update() {
        companyService.update(theCompany);
        verify(companyRepositoryInterface).save(theCompany);
    }

    @Test
    public void delete() {
        companyService.delete(1L);
        verify(companyRepositoryInterface).deleteById(1L);
    }

    @Test
    public void getByName() {
        companyService.getByName(theCompany.getName());
        verify(companyRepositoryInterface).getByName(theCompany.getName());
    }

    @Test
    public void getAllByServicesProvided() {
        ServicesProvider servicesProvider = IT;
        companyService.getAllByServicesProvided(servicesProvider);
        verify(companyRepositoryInterface).getAllByServicesProvided(servicesProvider);
    }
}