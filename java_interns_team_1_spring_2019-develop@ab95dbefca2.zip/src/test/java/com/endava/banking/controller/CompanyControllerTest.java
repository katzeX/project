package com.endava.banking.controller;

import com.endava.banking.config.SecurityConfig;
import com.endava.banking.model.Company;
import com.endava.banking.service.CompanyService;
import com.endava.banking.service.UserService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.servlet.ModelAndView;

import static com.endava.banking.model.ServicesProvider.IT;
import static org.mockito.Matchers.isA;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = CompanyController.class)
@ContextConfiguration(classes = SecurityConfig.class)
public class CompanyControllerTest {

    @Autowired
    MockMvc mockMvc;

    @InjectMocks
    CompanyController companyController;


    @MockBean
    CompanyService companyService;

    @MockBean
    UserService userService;


    @Before
    public void init() {
        MockitoAnnotations.initMocks(this);
        this.mockMvc = MockMvcBuilders.standaloneSetup(companyController).build();
    }

    @Test
    public void submitForm() throws Exception {
        Company company = new Company("test", IT);
        when(companyService.add(isA(Company.class))).thenReturn(company);

        this.mockMvc.perform(post("/company/add")
                .contentType(MediaType.APPLICATION_JSON)
                .sessionAttr("Company ", new Company())
        )
                .andExpect(view().name("redirect:/company#company"));


    }

    @Test
    public void findAll() throws Exception {
        this.mockMvc.perform(get("/company/find", new ModelAndView())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(view().name("companies"));
    }

    @Test
    public void deleteById() throws Exception {

        this.mockMvc.perform(get("/company/{id}", 1)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().is(302))
                .andExpect(view().name("redirect:/company#company"));

    }


    @Test
    public void submitData() throws Exception {

        this.mockMvc.perform(post("/update")
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(view().name("redirect:/company#company"));
    }
}