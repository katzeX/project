package com.endava.banking.controller.dto;


import java.util.Date;

public class UserTransactionsDto implements Comparable<UserTransactionsDto> {

    private long accountId;

    private float amount;

    private String accountName;

    private Date date;

    private String action;

    private String type;

    public UserTransactionsDto(long accountId, float amount, String accountName, Date date, String action, String type) {
        this.accountId = accountId;
        this.amount = amount;
        this.accountName = accountName;
        this.date = date;
        this.action = action;
        this.type = type;
    }

    public long getAccountId() {
        return accountId;
    }

    public void setAccountId(long accountId) {
        this.accountId = accountId;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public int compareTo(UserTransactionsDto o) {
        return this.getDate().compareTo(o.getDate());
    }
}
