package com.endava.banking.controller;

import com.endava.banking.model.Role;
import com.endava.banking.model.User;
import com.endava.banking.model.UserStatus;
import com.endava.banking.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Controller
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;


    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @GetMapping("/find")
    public String getUsers(Model model) {
        logger.info("Displaying user's information");

        List<User> userList = userService.findAll();
        Set<String> listRoles = new HashSet<>();
        Set<Role> roles = userService.findAllRoles();

        for (Role rol : roles
        ) {
            listRoles.add(rol.getName());
        }
        model.addAttribute("roles", listRoles);
        model.addAttribute("status", EnumSet.allOf(UserStatus.class));
        model.addAttribute("users", userList);
        return "users";
    }

    @PostMapping("/add")
    public String submitForm(@ModelAttribute User theUser) {
        logger.info("Updating the user {}", theUser.getEmail());
        userService.updateStatus(theUser.getUserStatus(), theUser.getId());
        userService.updateRole(theUser.getRoleName().equals("ROLE_ADMIN") ? 1 : 2, theUser.getId());

        return "redirect:/company#users";
    }

    @GetMapping("/findOne")
    @ResponseBody
    public User getById(int id) {
        return userService.getById(id);
    }

}
