package com.endava.banking.controller;

import com.endava.banking.model.Company;
import com.endava.banking.model.ServicesProvider;
import com.endava.banking.service.CompanyServiceInterface;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class CompanyController {


    @Autowired
    private CompanyServiceInterface companyServiceInterface;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @GetMapping("/company")
    public String mainPage(Model model) {
        model.addAttribute("username", MainController.getCurrentLogedUser().getFirstName());
        return "userPage";
    }


    @PostMapping("/company/add")
    public String submitForm(@ModelAttribute Company theCompany) {
        logger.info("Adding new company");
        companyServiceInterface.add(theCompany);
        return "redirect:/company#company";
    }

    @GetMapping("/company/find")
    public String findAll(Model model) {
        logger.info("Displaying all companies");
        model.addAttribute("companies", companyServiceInterface.findAll());
        model.addAttribute("services", ServicesProvider.values());
        return "companies";
    }

    @GetMapping("/findOne")
    @ResponseBody
    public Company getById(int id) {
        logger.info("Finding company by id:{}",id);
        return companyServiceInterface.getById(id);
    }

    @GetMapping("/findServices")
    @ResponseBody
    public ServicesProvider[] getServices() {
        logger.info("Finding services provided by a company");
        return ServicesProvider.values();
    }

    @GetMapping("/company/{id}")
    public String deleteById(@PathVariable int id) {
        logger.warn("Company with id:{} was deleted",id);
        companyServiceInterface.delete(id);
        return "redirect:/company#company";
    }

    @PostMapping("/update")
    public String submitData(@ModelAttribute Company theCompany) {
        logger.info("Updated {}",theCompany);
        companyServiceInterface.update(theCompany);
        return "redirect:/company#company";
    }

}
