package com.endava.banking.controller.dto;


import com.endava.banking.constraint.FieldMatch;

import javax.validation.constraints.NotEmpty;

@FieldMatch.List({
        @FieldMatch(first = "newPassword", second = "confirmNewPassword", message = "The password fields must match")
})
public class PasswordChangeDto {

    @NotEmpty
    private String curentPassword;

    @NotEmpty
    private String newPassword;

    @NotEmpty
    private String confirmNewPassword;


    public String getCurentPassword() {
        return curentPassword;
    }

    public void setCurentPassword(String curentPassword) {
        this.curentPassword = curentPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getConfirmNewPassword() {
        return confirmNewPassword;
    }

    public void setConfirmNewPassword(String confirmNewPassword) {
        this.confirmNewPassword = confirmNewPassword;
    }
}
