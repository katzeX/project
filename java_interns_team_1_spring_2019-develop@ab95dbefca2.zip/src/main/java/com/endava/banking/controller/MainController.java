package com.endava.banking.controller;

import com.endava.banking.controller.dto.UserTransactionsDto;
import com.endava.banking.model.User;
import com.endava.banking.model.UserStatus;
import com.endava.banking.service.AccountService;
import com.endava.banking.service.TransactionService;
import com.endava.banking.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Controller
public class MainController {

    @Autowired
    private UserService userService;

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private AccountService accountService;

    private static User currentLogedUser;

    @Value("${api.path}")
    private String api;


    private final Logger logger = LoggerFactory.getLogger(this.getClass());


    public static User getCurrentLogedUser() {
        return currentLogedUser;
    }

    private void setCurrentLogedUser(User currentLogedUser) {
        this.currentLogedUser = currentLogedUser;
    }

    @GetMapping("/banking")
    public String mainPage() {
        logger.info("Displaying the main page");
        return "userMainInterface";
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model, @RequestParam("page") Optional<Integer> page,
                            @RequestParam("size") Optional<Integer> size) {

        User user = getCurrentLogedUser();
        List<UserTransactionsDto> from = transactionService.retrieveTransactionsFromAsDTO(accountService.getAccountByIdCustomer(user.getId()).getIdAccount());
        List<UserTransactionsDto> to = transactionService.retrieveTransactionsToAsDTO(accountService.getAccountByIdCustomer(user.getId()).getIdAccount());

        int currentPage = page.orElse(1);
        int pageSize = size.orElse(10);

        List<UserTransactionsDto> dtos = transactionService.getAllUserTransactions(from, to);
        Page<UserTransactionsDto> bookPage = transactionService.findPaginated(PageRequest.of(currentPage - 1, pageSize), dtos);
        model.addAttribute("bookPage", bookPage);

        int totalPages = bookPage.getTotalPages();
        if (totalPages > 0) {
            List<Integer> pageNumbers = IntStream.rangeClosed(1, totalPages)
                    .boxed()
                    .collect(Collectors.toList());
            model.addAttribute("pageNumbers", pageNumbers);
        }

        model.addAttribute("userName", user.getFirstName() + " " + user.getLastName());
        model.addAttribute("accountNumber", accountService.getAccountByIdCustomer(user.getId()).getIdAccount());
        model.addAttribute("paymentItAmount", transactionService.getItPayments(accountService.getAccountByIdCustomer(user.getId()).getIdAccount()));
        model.addAttribute("paymentComunalAmount", transactionService.getComunalPayments(accountService.getAccountByIdCustomer(user.getId()).getIdAccount()));
        model.addAttribute("transactionAmount", transactionService.getTransactionsAmount(accountService.getAccountByIdCustomer(user.getId()).getIdAccount()));
        model.addAttribute("balance", accountService.getAccountByIdCustomer(user.getId()).getBalance());

        logger.info("Displaying the dashboard");
        return "user-dashboard";
    }

    @GetMapping("/")
    public String root(Model model, HttpServletRequest request) {
        Principal principal = request.getUserPrincipal();

        if (principal==null){
            return "userMainInterface";
        }
        else {
            User logedUser = userService.findByEmail(principal.getName());
        setCurrentLogedUser(logedUser);
        if (logedUser.getUserStatus().equals(UserStatus.BLOCKED)) {
            logger.warn("Blocked user whith email {}", logedUser.getEmail());
            return "redirect:/login?blocked";
        }
        logger.info("Redirecting user to path with role :{}", currentLogedUser.getRoles().iterator().next().getName());
        model.addAttribute("username", logedUser.getFirstName() + " " + logedUser.getLastName());
        return currentLogedUser.getRoles().iterator().next().getName().equals("ROLE_ADMIN") ? "redirect:/company" : "redirect:/dashboard";}
    }

    @GetMapping("/login")
    public String login() {
        return "userMainInterface";
    }

    @PostMapping("/login")
    public String logedIn() {
        return "companies";
    }

    @GetMapping("/user")
    public String userIndex() {
        return "user/index";
    }

    @GetMapping("/credit")
    public String credit(Model model) {
        model.addAttribute("balance", accountService.getAccountByIdCustomer(currentLogedUser.getId()).getBalance());
        model.addAttribute("api", api);
        return "credit";
    }

    @GetMapping("/credit/path")
    public String creditApi() {

        return "redirect:"+api;
    }

}
