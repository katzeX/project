package com.endava.banking.controller;


import com.endava.banking.controller.dto.PasswordChangeDto;
import com.endava.banking.model.Company;
import com.endava.banking.model.PaymentStatus;
import com.endava.banking.service.AccountService;
import com.endava.banking.service.CompanyService;
import com.endava.banking.service.TransactionService;
import com.endava.banking.service.UserServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.validation.Valid;
import java.util.List;

import static com.endava.banking.model.AccountType.INDIVIDUAL;
import static com.endava.banking.model.AccountType.LEGAL;
import static com.endava.banking.model.PaymentStatus.PENDING;
import static com.endava.banking.model.PaymentStatus.REJECTED;
import static com.endava.banking.model.ServicesProvider.COMUNAL;
import static com.endava.banking.model.ServicesProvider.IT;


@Controller
public class PaymentController {

    @Autowired
    private CompanyService companyService;

    @Autowired
    private AccountService accountService;

    @Autowired
    private UserServiceImpl userService;

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    private long getLogedUserID() {
        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        return userService.findByEmail(user.getUsername()).getId();
    }

    @GetMapping("/payments")
    public String findCompaniesByService(Model model) {
        logger.info("Displaying companies by services provided");
        List<Company> comunal = companyService.getAllByServicesProvided(COMUNAL);
        List<Company> it = companyService.getAllByServicesProvided(IT);
        model.addAttribute("companiesComunal", comunal);
        model.addAttribute("companiesIT", it);
        model.addAttribute("balance", accountService.getAccountByIdCustomer(getLogedUserID()).getBalance());
        return "payment";
    }

    @GetMapping("/{name}")
    public String findReceiptForm(@PathVariable String name, Model m) {
        logger.info("Displaying receipt form");
        m.addAttribute("account", accountService.getAccountByIdCustomerAndAccountType(getLogedUserID(), INDIVIDUAL.getId()).getIdAccount());
        Company company = companyService.getByName(name);
        m.addAttribute("company", company);
        m.addAttribute("balance", accountService.getAccountByIdCustomer(getLogedUserID()).getBalance());
        return company.getServicesProvided() == COMUNAL ? "billNumber" : "telecomunicationReceipt";
    }

    @GetMapping(value = "/{name}/receipt")
    public String billNumber(@PathVariable String name, Model m) {
        m.addAttribute("account", accountService.getAccountByIdCustomerAndAccountType(getLogedUserID(), INDIVIDUAL.getId()).getIdAccount());
        Company company = companyService.getByName(name);
        m.addAttribute("balance", accountService.getAccountByIdCustomer(getLogedUserID()).getBalance());
        m.addAttribute("company", company);
        logger.info("Displaying comunal receipt");
        return "comunalReceipt";
    }

    @GetMapping("/transfers")
    public String transfer(Model n) {
        n.addAttribute("account", accountService.getAccountByIdCustomerAndAccountType(getLogedUserID(), INDIVIDUAL.getId()).getIdAccount());
        n.addAttribute("balance", accountService.getAccountByIdCustomer(getLogedUserID()).getBalance());
        logger.info("Getting all transfers");
        return "transferReceipt";
    }

    @PostMapping(value = "/transfers/payment")
    public String transferPayment(@RequestParam long sourceAccount, @RequestParam long destinationAccount, @RequestParam float amount, Model m) {

        if (!accountService.existsAccountByIdAccount(destinationAccount)) {
            logger.warn("There is no account with id {}",destinationAccount);
            m.addAttribute("balance", accountService.getAccountByIdCustomer(getLogedUserID()).getBalance());
            return "errorPayment.html";
        } else {
            PaymentStatus status = transactionService.transfer(sourceAccount, destinationAccount, amount);
            m.addAttribute("balance", accountService.getAccountByIdCustomer(getLogedUserID()).getBalance());
            if (status == PENDING) {
                logger.warn("Transaction in PENDING");
                return "pendingPayment";
            } else if (status == REJECTED) {
                logger.warn("Transaction failed");
                return "errorPayment";
            }
            return "successPayment";
        }
    }

    @PostMapping(value = "/receipt/payment")
    public String receiptPayment(@RequestParam long sourceAccount, @RequestParam long destinationAccount, @RequestParam float amount, Model m) {
        PaymentStatus status = transactionService.transfer(sourceAccount, accountService.getAccountByIdCustomerAndAccountType(destinationAccount, LEGAL.getId()).getIdAccount(), amount);
        m.addAttribute("balance", accountService.getAccountByIdCustomer(getLogedUserID()).getBalance());
        if (status == PENDING) {
            logger.warn("Payment in PENDING");
            return "pendingPayment";
        } else if (status == REJECTED) {
            logger.warn("Payment REJECTED");
            return "errorPayment";
        } else return "successPayment";
    }

    @GetMapping("/resetPassword")
    public String changePassword(Model model) {
        logger.warn("Changing password");
        model.addAttribute("balance", accountService.getAccountByIdCustomer(getLogedUserID()).getBalance());
        return "passwordChange";
    }

    @ModelAttribute("passwordChangeDto")
    public PasswordChangeDto userRegistrationDto() {
        return new PasswordChangeDto();
    }

    @PostMapping("/resetPassword")
    public String submit(@ModelAttribute("passwordChangeDto") @Valid PasswordChangeDto passwordChangeDto,
                         BindingResult result, RedirectAttributes redirectAttributes, Model model) {
        model.addAttribute("balance", accountService.getAccountByIdCustomer(getLogedUserID()).getBalance());
        if (result.hasErrors()) {
            logger.warn("Error on completing the password reset form");
            return "passwordChange";
        }
        User user = (User) SecurityContextHolder.getContext().getAuthentication().getPrincipal();

        if (passwordEncoder.matches(passwordChangeDto.getCurentPassword(), userService.findByEmail(user.getUsername()).getPassword())) {
            logger.info("Password was changed");
            userService.updatePassword(passwordChangeDto.getNewPassword(), getLogedUserID());
            model.addAttribute("changed", "Your password has been succesfuly changed");

        }
        return "passwordChange";
    }
}
