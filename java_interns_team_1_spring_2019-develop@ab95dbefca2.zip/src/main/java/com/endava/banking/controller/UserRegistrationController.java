package com.endava.banking.controller;

import com.endava.banking.controller.dto.UserRegistrationDto;
import com.endava.banking.model.User;
import com.endava.banking.model.UserStatus;
import com.endava.banking.model.VerificationToken;
import com.endava.banking.service.EmailService;
import com.endava.banking.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import java.util.Calendar;
import java.util.UUID;

@Controller
@RequestMapping("/registration")
public class UserRegistrationController {

    @Autowired
    private UserService userService;

    @Autowired
    private EmailService emailService;
    @Value("${email.subject}")
    private String subject;

    @Value("${email.text}")
    private String emailText;

    @Value("${email.from}")
    private String from;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @ModelAttribute("user")
    public UserRegistrationDto userRegistrationDto() {
        return new UserRegistrationDto();
    }

    @GetMapping
    public String showRegistrationForm() {
        return "registration";
    }

    @PostMapping
    public String registerUserAccount(@ModelAttribute("user") @Valid UserRegistrationDto userDto,
                                      BindingResult result, HttpServletRequest request, RedirectAttributes redirectAttributes) {

        User existing = userService.findByEmail(userDto.getEmail());
        if (existing != null) {
            result.rejectValue("email", null, "There is already an account registered with that email");
            logger.warn("There is already registred user whith that email");
        }

        if (result.hasErrors()) {
            logger.warn("Registration failed");
            return "registration";
        }
        User savedUser = userService.update(userDto);

        userService.update(savedUser);
        String token = UUID.randomUUID().toString();
        userService.createVerificationToken(savedUser, token);


        String appUrl = request.getScheme() + "://" + request.getServerName() + ":" + request.getLocalPort() + "/banking/registration";

        SimpleMailMessage registrationEmail = new SimpleMailMessage();
        registrationEmail.setTo(savedUser.getEmail());

        registrationEmail.setSubject(subject);
        registrationEmail.setText(emailText
                + appUrl + "/confirm?token=" + token);
        registrationEmail.setFrom(from);
        emailService.sendEmail(registrationEmail);
        logger.info("Confirmation message has been sent");
        redirectAttributes.addFlashAttribute("message", "A confirmation email has been sent to " + userDto.getEmail());
        return "redirect:/registration?success";
    }

    @GetMapping("/confirm")
    public ModelAndView showConfirmationPage(ModelAndView modelAndView, @RequestParam("token") String token) {

        VerificationToken verificationToken = userService.getVerificationToken(token);

        if (verificationToken == null) {

            logger.error("Invalid confirmation token");
            modelAndView.addObject("invalidToken", "Invalid Confirmation link");
            modelAndView.setViewName("userMainInterface");
            return modelAndView;

        }

        Calendar calendar = Calendar.getInstance();

        User user = userService.getUser(verificationToken.getToken());
        if ((verificationToken.getExpiryDate().getTime() - calendar.getTime().getTime()) <= 0) {
            logger.error("Authentification expired");
            userService.deleteUserAfterLinkExpired(user.getId());
            modelAndView.addObject("confirmationToken", "Authentification expired");
            modelAndView.setViewName("userMainInterface");
            return modelAndView;
        }

        userService.updateStatus(UserStatus.ACTIVE, user.getId());
        //Droping Tokens older than 24 hours
        userService.dropOldTokens();
        modelAndView.addObject("succesfulRegistration", "You have been succesfully registred");
        logger.info("The new user has been succesfully registred");
        modelAndView.setViewName("userMainInterface");
        return modelAndView;
    }

}
