package com.endava.banking.controller;

import com.endava.banking.controller.dto.TransactionInfoDto;
import com.endava.banking.controller.dto.TransactionInfoSelectDto;
import com.endava.banking.controller.dto.UserTransactionsDto;
import com.endava.banking.model.Transactions;
import com.endava.banking.repository.TransactionsRepository;
import com.endava.banking.service.AccountService;
import com.endava.banking.service.TransactionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;


@Controller
public class TransferController {

    @Autowired
    private AccountService accountsService;

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private TransactionsRepository transactionsRepository;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @GetMapping("/account")
    public String getAccounts(Model model) {
        model.addAttribute("accountsinfo", accountsService.getAccountsInfo());
        logger.info("Displaying all accounts");
        model.addAttribute("accounts", accountsService.getAll());
        model.addAttribute("serviceAccount", accountsService);
        return "account";
    }

    @GetMapping("/transfer/{id}")
    public String transfer(@PathVariable String id, Model model) {
        logger.info("Getting transfer by id: {}",id);
        model.addAttribute("id", id);
        return "transfer";
    }

    @GetMapping("/transfered")
    public String transfered(@RequestParam long id, @RequestParam long to, @RequestParam float amount, Model model) {
        logger.warn("Transfer with amount {}",amount);
        if (!accountsService.existsAccountByIdAccount(to)){return "redirect:/transfer/"+id;}
        else{
        transactionService.transfer(id, to, amount);
        return "redirect:/company#account";}
    }

    @GetMapping("/transactions")
    public String getTransactions(Model model, @RequestParam(value = "page",defaultValue = "1") int page, @RequestParam(value = "size",defaultValue = "25") int size) {
        model.addAttribute("transactions", transactionService.getSelectFrom());
        model.addAttribute("transactionsto",transactionService.getSelectTo());
        logger.info("Displaying all transactions");
        model.addAttribute("serviceAccount", accountsService);
        model.addAttribute("page",page);
        model.addAttribute("size",size);
        int currentPage = page;
        int pageSize = size;

        List<TransactionInfoDto> list = transactionService.getTransactionsInfo();
        Page<TransactionInfoDto> bookPage = transactionService.findPaginatedTransactions(PageRequest.of(currentPage - 1, pageSize), list);
        model.addAttribute("bookPage", bookPage);
        int totalPages = bookPage.getTotalPages();
        if (totalPages > 0) {
            List<Integer> pageNumbers = IntStream.rangeClosed(1, totalPages)
                    .boxed()
                    .collect(Collectors.toList());
            model.addAttribute("pageNumbers", pageNumbers);
        }
        return "transactions";
    }

    @GetMapping("/transaction/approvements")
    public String getPending(Model model) {
        model.addAttribute("transactions", transactionService.getAllPending());
        logger.info("Transactions int Pending");
        return "approvements";
    }

    @GetMapping("/transaction/approve/{id}")
    public String approvePending(@PathVariable int id) {
        transactionService.approvePending(transactionService.getByID(id));
        logger.info("Transaction with id: {} approved",id);
        return "redirect:/company#approvements";
    }

    @GetMapping("/transaction/approve/delete/{id}")
    public String declinePending(@PathVariable int id) {
        transactionService.declinePending(transactionService.getByID(id));
        return "redirect:/company#approvements";
    }
}
