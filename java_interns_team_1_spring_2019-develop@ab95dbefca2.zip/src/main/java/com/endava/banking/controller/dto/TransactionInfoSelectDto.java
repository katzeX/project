package com.endava.banking.controller.dto;

import com.endava.banking.model.PaymentStatus;

import java.util.Date;

public class TransactionInfoSelectDto {

    private long id;

    private long from;

    private long to;

    private float amount;

    private Date date;

    private PaymentStatus status;

    private int type;

    private String idk;

    public TransactionInfoSelectDto(long id, long from, long to, float amount, Date date, PaymentStatus status, int type, String idk) {
        this.id = id;
        this.from = from;
        this.to = to;
        this.amount = amount;
        this.date = date;
        this.status = status;
        this.type = type;
        this.idk = idk;
    }

    public TransactionInfoSelectDto(long to, String idk) {
        this.to = to;
        this.idk = idk;
    }

    public String getIdk() {
        return idk;
    }

    public void setIdk(String idk) {
        this.idk = idk;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getFrom() {
        return from;
    }

    public void setFrom(long from) {
        this.from = from;
    }

    public long getTo() {
        return to;
    }

    public void setTo(long to) {
        this.to = to;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public PaymentStatus getStatus() {
        return status;
    }

    public void setStatus(PaymentStatus status) {
        this.status = status;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
