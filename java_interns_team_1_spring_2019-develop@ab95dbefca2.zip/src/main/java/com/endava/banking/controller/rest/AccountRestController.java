package com.endava.banking.controller.rest;

import com.endava.banking.model.Account;
import com.endava.banking.model.Client;
import com.endava.banking.model.User;
import com.endava.banking.service.AccountService;
import com.endava.banking.service.ClientService;
import com.endava.banking.service.UserService;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.endava.banking.model.AccountType.INDIVIDUAL;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

@RestController
public class AccountRestController {

    private static final Logger LOGGER = LogManager.getLogger(AccountRestController.class);

    @Autowired
    private AccountService accountService;

    @Autowired
    private UserService userService;

    @Autowired
    private ClientService clientService;

    private String jsonUserNotPresent = "{\"message\":\"User is not present\"}";
    private String jsonAccount = "{\"message\":\"Account doesn't exist\"}";


    @GetMapping("/api/account/{username}")
    public ResponseEntity<Object> getAccountId(@PathVariable String username) {

        User user = userService.findByEmail(username);
        if (user == null) {
            LOGGER.info("API request about not existent user.");
            return new ResponseEntity<>(jsonUserNotPresent, HttpStatus.BAD_REQUEST);
        } else {
            Account account = accountService.getAccountByIdCustomerAndAccountType(user.getId(), INDIVIDUAL.getId());
            String accountId = Long.toString(account.getIdAccount());
            Map<String, String> body = new HashMap<>();
            body.put("AccountID", accountId);

            LOGGER.info("API account details request about user " + username);
            return new ResponseEntity<>(body, HttpStatus.OK);
        }
    }

    @GetMapping("/api/accountinfo/{username}")
    public ResponseEntity<Object> getAccountAndBalance(@PathVariable String username) {

        User user = userService.findByEmail(username);
        if (user == null) {
            LOGGER.info("API request about not existent user.");
            return new ResponseEntity<>(jsonUserNotPresent, HttpStatus.BAD_REQUEST);
        } else {
            Account account = accountService.getAccountByIdCustomerAndAccountType(user.getId(), INDIVIDUAL.getId());
            String accountId = Long.toString(account.getIdAccount());
            String balance = Float.toString(account.getBalance());
            Map<String, String> body = new HashMap<>();
            body.put("AccountID", accountId);
            body.put("Balance", balance);

            LOGGER.info("API account details request about user " + username);
            return new ResponseEntity<>(body, HttpStatus.OK);
        }
    }

    @GetMapping("/api/credit/payment/{accountId}/{sum}")
    public ResponseEntity<String> creditPayment(@PathVariable String accountId, @PathVariable String sum) {

        long accountID = Long.parseLong(accountId);
        float amount = Float.parseFloat(sum);

        if (!accountService.existsAccountByIdAccount(accountID)) {
            LOGGER.info("API request about not existent account.");
            return new ResponseEntity<>(jsonAccount, HttpStatus.BAD_REQUEST);
        } else if (accountService.getByID(accountID).getBalance() < amount) {
            String json = "{\"message\":\"Not enough money\"}";
            return new ResponseEntity<>(json, HttpStatus.BAD_REQUEST);
        } else {
            accountService.creditPayment(accountID, amount);
            String json = "{\"message\":\"Payment successful\"}";
            LOGGER.info(accountId + ": successful credit payment with amount of " + sum);
            return new ResponseEntity<>(json, HttpStatus.OK);
        }
    }

    @GetMapping("/api/credit/deposit/{accountId}/{sum}")
    public ResponseEntity<String> creditDeposit(@PathVariable String accountId, @PathVariable String sum) {

        long accountID = Long.parseLong(accountId);
        float amount = Float.parseFloat(sum);

        if (!accountService.existsAccountByIdAccount(accountID)) {
            LOGGER.info("API request about not existent account.");
            return new ResponseEntity<>(jsonAccount, HttpStatus.BAD_REQUEST);
        } else {
            accountService.creditDeposit(accountID, amount);
            String json = "{\"message\":\"Deposit successful\"}";
            LOGGER.info(accountId + ": successful deposit with amount of " + amount);
            return new ResponseEntity<>(json, HttpStatus.OK);
        }
    }

    @GetMapping("/api/salary/{username}")
    public ResponseEntity<Object> getCustomerSalary(@PathVariable String username) {

        User user = userService.findByEmail(username);
        if (user == null) {
            LOGGER.info("API request about not existent user..");
            return new ResponseEntity<>(jsonUserNotPresent, HttpStatus.BAD_REQUEST);
        } else if (!accountService.existsAccountByIdCustomer(user.getId())) {
            String json = "{\"message\":\"No information about client salary\"}";
            LOGGER.info("API request about " + username + " salary. No info found.");
            return new ResponseEntity<>(json, HttpStatus.BAD_REQUEST);
        } else {
            String salary = Float.toString(clientService.getClientByIdCustomer(user.getId()).getSalary());
            Map<String, String> body = new HashMap<>();
            body.put("Salary", salary);
            LOGGER.info("Succesful API request about " + username + " salary.");
            return new ResponseEntity<>(body, HttpStatus.OK);
        }
    }

    @GetMapping("/api/customerinfo/{accountId}")
    public ResponseEntity<Object> getCustomerInfo(@PathVariable String accountId) {

        if (!accountService.existsAccountByIdAccount(Long.parseLong(accountId))) {
            return new ResponseEntity<>(jsonAccount, HttpStatus.BAD_REQUEST);
        } else {
            Client client = clientService.getClientByIdCustomer(accountService.getByID(Long.parseLong(accountId)).getIdCustomer());
            if (client == null) {
                LOGGER.info("No info about this client.");
                return new ResponseEntity<>(jsonUserNotPresent, HttpStatus.BAD_REQUEST);
            }
            Map<String, String> body = new HashMap<>();
            body.put("IdCustomer", Long.toString(client.getIdCustomer()));
            body.put("name", client.getName());
            body.put("surname", client.getSurname());
            body.put("salary", Float.toString(client.getSalary()));
            body.put("idnp", Integer.toString(client.getIdnp()));

            LOGGER.info("Succesful API request about " + accountId + " client account.");
            return new ResponseEntity<>(body, HttpStatus.OK);
        }

    }

    @RequestMapping(value = "/api/credit/emails", method = POST)
    public ResponseEntity<Map<Long, String>> getAccountsEmails(@RequestParam("ids") List<String> ids) {

        Map<Long, String> emails = new HashMap<>();
        for (String id : ids) {
            long idAccount = Long.parseLong(id);
            if (accountService.existsAccountByIdAccount(idAccount)) {
                emails.put(idAccount, userService.getByAccountId(idAccount).getEmail());
            }
        }
        LOGGER.info("Succesful API request about users emails.");
        return new ResponseEntity<>(emails, HttpStatus.OK);
    }

}
