package com.endava.banking.controller.dto;

import com.endava.banking.model.PaymentStatus;

import java.util.Date;

public class TransactionInfoDto {

    private long id;

    private long from;

    private long to;

    private float amount;

    private Date date;

    private PaymentStatus paymentStatus;

    private String from_name;

    private String to_name;

    private int type;

    public TransactionInfoDto(long id, long from, long to, float amount, Date date, PaymentStatus paymentStatus, String from_name, String to_name, int type) {
        this.id = id;
        this.from = from;
        this.to = to;
        this.amount = amount;
        this.date = date;
        this.paymentStatus = paymentStatus;
        this.from_name = from_name;
        this.to_name = to_name;
        this.type = type;
    }

    public TransactionInfoDto(long id, long from, long to, float amount, Date date, PaymentStatus paymentStatus, String from_name, int type) {
        this.id = id;
        this.from = from;
        this.to = to;
        this.amount = amount;
        this.date = date;
        this.paymentStatus = paymentStatus;
        this.from_name = from_name;
        this.type = type;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getFrom() {
        return from;
    }

    public void setFrom(long from) {
        this.from = from;
    }

    public long getTo() {
        return to;
    }

    public void setTo(long to) {
        this.to = to;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public PaymentStatus getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(PaymentStatus paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getFrom_name() {
        return from_name;
    }

    public void setFrom_name(String from_name) {
        this.from_name = from_name;
    }

    public String getTo_name() {
        return to_name;
    }

    public void setTo_name(String to_name) {
        this.to_name = to_name;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }
}
