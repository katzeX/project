package com.endava.banking.controller.dto;

public class AccountInfoDto {

    private long id;

    private String account;

    private long idCustomer;

    private String accountType;

    private float balance;

    public AccountInfoDto(long id,String account, long idCustomer, String accountType, float balance) {
        this.id = id;
        this.account = account;
        this.idCustomer = idCustomer;
        this.accountType = accountType;
        this.balance = balance;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public long getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(long idCustomer) {
        this.idCustomer = idCustomer;
    }

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
}
