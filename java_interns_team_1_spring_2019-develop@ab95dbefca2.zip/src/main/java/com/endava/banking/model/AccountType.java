package com.endava.banking.model;

public enum AccountType {
    INDIVIDUAL(1), LEGAL(2);

    int id;

    AccountType(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}
