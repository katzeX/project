package com.endava.banking.model;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.CascadeType;

@Entity
@Table(name = "account")
public class Account {

    @Id
    @Column(name = "id_account")
    private long idAccount;

    @Column(name = "id_customer")
    private long idCustomer;

    @Column(name = "balance")
    private float balance;

    @Column(name = "account_type")
    private int accountType;

    @JoinColumn(name = "id")
    @OneToOne(cascade = CascadeType.ALL)
    private User user;

    public Account() {
    }

    public Account(long idAccount, long idCustomer, float balance, int accountType) {
        this.idAccount = idAccount;
        this.idCustomer = idCustomer;
        this.balance = balance;
        this.accountType = accountType;
    }

    public long getIdAccount() {
        return idAccount;
    }

    public void setIdAccount(long idAccount) {
        this.idAccount = idAccount;
    }

    public long getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(long idCustomer) {
        this.idCustomer = idCustomer;
    }

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    public int getAccountType() {
        return accountType;
    }

    public void setAccountType(int accountType) {
        this.accountType = accountType;
    }
}
