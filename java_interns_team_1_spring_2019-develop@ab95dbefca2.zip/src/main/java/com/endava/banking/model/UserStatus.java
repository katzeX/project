package com.endava.banking.model;

public enum UserStatus {
    ACTIVE, BLOCKED
}
