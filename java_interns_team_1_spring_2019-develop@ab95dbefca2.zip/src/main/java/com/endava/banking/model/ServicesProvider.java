package com.endava.banking.model;

public enum ServicesProvider {
    IT, COMUNAL, ENSURANCE
}
