package com.endava.banking.model;

public enum PaymentStatus {
    PENDING, REJECTED, DONE
}