package com.endava.banking.model;


import javax.persistence.*;


@Entity
@Table(name = "company")
public class Company {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_customer")
    private long idCustomer;

    @Column(name = "company_name")
    private String name;

    @Column(name = "services")
    @Enumerated(EnumType.STRING)
    private ServicesProvider servicesProvided;

    public Company() {
    }

    public Company(String name, ServicesProvider servicesProvided) {
        this.name = name;
        this.servicesProvided = servicesProvided;
    }

    public long getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(long idCustomer) {
        this.idCustomer = idCustomer;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ServicesProvider getServicesProvided() {
        return servicesProvided;
    }

    public void setServicesProvided(ServicesProvider servicesProvided) {
        this.servicesProvided = servicesProvided;
    }

    @Override
    public String toString() {
        return "Company{" +
                "idCustomer=" + idCustomer +
                ", name='" + name + '\'' +
                ", servicesProvided=" + servicesProvided +
                '}';
    }
}
