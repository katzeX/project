package com.endava.banking.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name = "Transactions")
public class Transactions {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_trans", updatable = false, nullable = false)
    private long idTransactions;
    @Column(name = "from_account")
    private long fromAccount;
    @Column(name = "to_account")
    private long toAccount;
    @Column(name = "amount")
    private float amount;
    @Column(name = "date")
    private Timestamp date;
    @Column(name = "status")
    private PaymentStatus status;

    public Transactions() {
    }

    public Transactions(long fromAccount, long toAccount, float amount, Timestamp date, PaymentStatus status) {
        this.fromAccount = fromAccount;
        this.toAccount = toAccount;
        this.amount = amount;
        this.date = date;
        this.status = status;
    }

    public long getIdTransactions() {
        return idTransactions;
    }

    public void setIdTransactions(long idTransactions) {
        this.idTransactions = idTransactions;
    }

    public long getFromAccount() {
        return fromAccount;
    }

    public void setFromAccount(long fromAccount) {
        this.fromAccount = fromAccount;
    }

    public long getToAccount() {
        return toAccount;
    }

    public void setToAccount(long toAccount) {
        this.toAccount = toAccount;
    }

    public float getAmount() {
        return amount;
    }

    public void setAmount(float amount) {
        this.amount = amount;
    }

    public Timestamp getDate() {
        return date;
    }

    public void setDate(Timestamp date) {
        this.date = date;
    }

    public PaymentStatus getStatus() {
        return status;
    }

    public void setStatus(PaymentStatus status) {
        this.status = status;
    }
}
