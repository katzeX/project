package com.endava.banking.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "client")
public class Client {

    @Id
    @Column(name = "id_customer")
    private long idCustomer;

    @Column(name = "name")
    private String name;

    @Column(name = "surname")
    private String surname;

    @Column(name = "salary")
    private float salary;

    @Column(name = "idnp")
    private int idnp;

    @JoinColumn(name = "id_customer")
    @OneToOne(cascade = CascadeType.ALL)
    private Account account;

    public Client() {
    }

    public Client(String name, String surname, float salary, int idnp) {
        this.name = name;
        this.surname = surname;
        this.salary = salary;
        this.idnp = idnp;
    }

    public long getIdCustomer() {
        return idCustomer;
    }

    public void setIdCustomer(long idCustomer) {
        this.idCustomer = idCustomer;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public float getSalary() {
        return salary;
    }

    public void setSalary(float salary) {
        this.salary = salary;
    }

    public int getIdnp() {
        return idnp;
    }

    public void setIdnp(int idnp) {
        this.idnp = idnp;
    }
}