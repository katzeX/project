package com.endava.banking.utils;

import com.endava.banking.model.Account;
import com.endava.banking.model.Client;
import com.endava.banking.model.PaymentStatus;
import com.endava.banking.model.Transactions;
import com.endava.banking.service.AccountService;
import com.endava.banking.service.ClientService;
import com.endava.banking.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;


public class Transfer {
    @Autowired
    private AccountService accountService;

    @Autowired
    private TransactionService transactionService;

    @Autowired
    private ClientService clientService;

    public void transfer(long from, long to, float amount) {
        Account account = accountService.getByID(from);
        account.setBalance(account.getBalance() - amount);
        accountService.update(from, account);
        Account account1 = accountService.getByID(to);
        account1.setBalance(account1.getBalance() + amount);
        accountService.update(to, account1);
    }

    public void transactions(long from, long to, float amount, Timestamp date, PaymentStatus status) {
        Transactions transactions = new Transactions(from, to, amount, date, status);
        transactionService.add(transactions);
    }

    @Scheduled(cron = "0 0 1 * * *")
    public void salary() {
        Date date = new Date();
        Timestamp ts = new Timestamp(date.getTime());
        List<Client> clientList = clientService.getAllClients();
        List<Account> accountList = accountService.getAll();
        for (Account a : accountList) {
            for (Client c : clientList) {
                if (a.getIdCustomer() == c.getIdCustomer() && a.getAccountType() == 1) {
                    a.setBalance(a.getBalance() + c.getSalary());
                    accountService.update(a.getIdAccount(), a);
                    transactionService.add(new Transactions(00000000L,a.getIdAccount(),c.getSalary(),ts,PaymentStatus.DONE));
                }
            }
        }
    }

    @Scheduled(cron = "0 0 * * * *")
    public void cleanTransactions() {
        Date date = new Date();
        Timestamp ts = new Timestamp(date.getTime());
        List<Transactions> transactionsList = transactionService.getAll();
        for (Transactions tr : transactionsList) {
            if ((ts.getTime() - tr.getDate().getTime()) >= 7776000000L) {
                transactionService.remove(tr.getIdTransactions());
            }
        }
    }

}
