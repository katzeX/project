package com.endava.banking.utils;


public class RandomLong {

    public static Long getRandomNumberInRange() {
        long leftLimit = 10000000000000000L;
        long rightLimit = Long.MAX_VALUE;
        long generatedLong = leftLimit + (long) (Math.random() * (rightLimit - leftLimit));

        return generatedLong;
    }
}
