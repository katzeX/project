package com.endava.banking.repository;

import com.endava.banking.model.Role;
import com.endava.banking.model.User;
import com.endava.banking.model.UserStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    User findByEmail(String email);

    @Transactional
    @Modifying
    @Query(value = "UPDATE User u  SET u.userStatus=:newStatus where u.id=:paramId")
    void updateStatus(@Param("newStatus") UserStatus newStatus, @Param("paramId") Long paramId);

    @Transactional
    @Modifying
    @Query(value = "UPDATE users_roles  SET role_id=:newRoleId where user_id=:paramId", nativeQuery = true)
    void updateRole(@Param("newRoleId") int newRole, @Param("paramId") Long paramId);

    @Transactional
    @Modifying
    @Query(value = "INSERT into users_roles  (role_id,user_id) VALUES (:newRoleId,:newUserId)", nativeQuery = true)
    void assignRole(@Param("newRoleId") Long newRole, @Param("newUserId") Long paramId);

    @Transactional
    @Modifying
    @Query(value = " DELETE FROM users_roles where user_id=:id", nativeQuery = true)
    void deleteUserRolesById(@Param("id") Long userId);

    @Transactional
    @Modifying
    @Query(value = " DELETE FROM users where id=:id", nativeQuery = true)
    void deleteUserById(@Param("id") Long userId);

    @Transactional
    @Modifying
    @Query(value = "UPDATE users  SET password=:newPassword where id=:paramId", nativeQuery = true)
    void updatePassword(@Param("newPassword") String newPassword, @Param("paramId") Long paramId);

    @Transactional
    @Modifying
    @Query(value = "select u from User u left join fetch u.roles")
    List<User> findAllUsersAndRole();

    @Transactional
    @Modifying
    @Query(value = "SELECT c FROM Role c")
    Set<Role> findAllRoles();
}
