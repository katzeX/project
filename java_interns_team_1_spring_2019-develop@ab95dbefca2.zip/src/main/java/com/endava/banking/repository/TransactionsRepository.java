package com.endava.banking.repository;


import com.endava.banking.controller.dto.TransactionInfoSelectDto;
import com.endava.banking.controller.dto.UserTransactionsDto;
import com.endava.banking.model.PaymentStatus;
import com.endava.banking.model.Transactions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TransactionsRepository extends JpaRepository<Transactions, Long> {

    List<Transactions> getByStatus(@Param("id") PaymentStatus id);

    @Query("select new com.endava.banking.controller.dto.UserTransactionsDto(t.toAccount, t.amount,  " +
            "case when a.accountType = 1 then concat(concat(u.firstName,' '), u.lastName) else co.name end, t.date," +
            "case When a.accountType = 1 then 'Transaction to' else'Payment to' end , '-') " +
            "from Transactions t " +
            "left join Account a on a.idAccount = t.toAccount " +
            "left join User u on u.id = a.idCustomer " +
            "left join Company co on co.idCustomer = a.idCustomer where t.status=2 AND t.fromAccount=:idAccount")
    List<UserTransactionsDto> retrieveTransactionsFromAsDTO(@Param("idAccount") long idAccount);


    @Query("select new com.endava.banking.controller.dto.UserTransactionsDto(t.fromAccount, t.amount,  " +
            "case when a.accountType = 1 then concat(concat(u.firstName,' '), u.lastName) else 'Salary' end, t.date," +
            "case When a.accountType = 1 then 'Transaction from' else 'Monthly' end , '+') " +
            "from Transactions t " +
            "left join Account a on a.idAccount = t.fromAccount " +
            "left join User u on u.id = a.idCustomer where t.status=2 AND t.toAccount=:idAccount")
    List<UserTransactionsDto> retrieveTransactionsToAsDTO(@Param("idAccount") long idAccount);


    @Query(" select sum(t.amount) from Transactions t left join Account a on a.idAccount = t.toAccount where  t.status=2 AND t.fromAccount=:idAccount and a.accountType=1")
    Float getTransactionsAmount(@Param("idAccount") long idAccount);

    @Query("select sum(t.amount) from Transactions t left join Account a on a.idAccount = t.toAccount left join User u on u.id = a.idCustomer" +
            " left join Company co on co.idCustomer = a.idCustomer where t.status=2 AND t.fromAccount=:idAccount and co.servicesProvided='COMUNAL'  and a.accountType=2")
    Float getComunalPayments(@Param("idAccount") long idAccount);

    @Query("select sum(t.amount) from Transactions t left join Account a on a.idAccount = t.toAccount" +
            " left join Company co on co.idCustomer = a.idCustomer where t.status=2 AND t.fromAccount=:idAccount and co.servicesProvided='IT'  and a.accountType=2")
    Float getItPayments(@Param("idAccount") long idAccount);


    @Query("select new com.endava.banking.controller.dto.TransactionInfoSelectDto(t.idTransactions, t.fromAccount, t.toAccount, t.amount, t.date, t.status, a.accountType, " +
            "case when a.accountType = 1 then concat(concat(u.firstName,' '),u.lastName) " +
            "else co.name end) " +
            "from Transactions t left join Account a on " +
            "t.fromAccount=a.idAccount left join User u on u.id=a.idCustomer " +
            "left join Company co on co.idCustomer = a.idCustomer")
    List<TransactionInfoSelectDto> getSelectFrom();

    @Query("select new com.endava.banking.controller.dto.TransactionInfoSelectDto(t.toAccount," +
            "case when a.accountType = 1 then concat(concat(u.firstName,' '),u.lastName) " +
            "else co.name end) " +
            "from Transactions t left join Account a on " +
            "t.toAccount=a.idAccount left join User u on u.id=a.idCustomer " +
            "left join Company co on co.idCustomer = a.idCustomer")
    List<TransactionInfoSelectDto> getSelectTo();

}
