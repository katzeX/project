package com.endava.banking.repository;

import com.endava.banking.controller.dto.AccountInfoDto;
import com.endava.banking.model.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {

    Account getAccountByIdCustomerAndAccountType(long idCustomer, int accountType);

    Account getAccountByIdCustomer(long id);

    boolean existsAccountByIdAccount(@Param("id") long id);


    @Transactional
    @Modifying
    @Query(value = " DELETE FROM account where id_customer=:id",nativeQuery = true)
    void deleteAccountByUserId(@Param("id")Long userId);

    boolean existsAccountByIdCustomer(@Param("id") long id);

    @Query("select new com.endava.banking.controller.dto.AccountInfoDto(a.idAccount,case when a.accountType = 1 " +
            "then concat(concat(u.firstName,' '), u.lastName) else co.name end," +
            "a.idCustomer,case when a.accountType=1 then 'Individual' else 'Legal' end,a.balance)" +
            "from Account a " +
            "left join User u on a.idCustomer=u.id " +
            "left join Company co on co.idCustomer=a.idCustomer")
    List<AccountInfoDto> getAccountsInfo();
}

