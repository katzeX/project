package com.endava.banking.repository;

import com.endava.banking.model.Client;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClientRepository extends JpaRepository<Client, Long> {

    Client getClientByIdCustomer(long id);
}
