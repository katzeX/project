package com.endava.banking.service;

import com.endava.banking.controller.dto.UserRegistrationDto;
import com.endava.banking.model.Role;
import com.endava.banking.model.User;
import com.endava.banking.model.UserStatus;
import com.endava.banking.model.VerificationToken;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;
import java.util.Set;

public interface UserService extends UserDetailsService {

    User findByEmail(String email);

    User update(UserRegistrationDto registration);

    User update(User theUser);

    List<User> findAll();

    User getById(long id);

    void updateStatus(UserStatus userStatus, Long id);

    void updateRole(int newRoleId, Long id);


    User getUser(String verificationToken);

    void createVerificationToken(User user, String token);

    VerificationToken getVerificationToken(String VerificationToken);

    void assighnRole(Long newRole, Long paramId);

    void deleteUserById(Long id);

    void deleteVerificationTokenByUserId(Long id);

    void deleteUserRolesById(Long userId);

    void deleteUserAfterLinkExpired(Long userId);

    void dropOldTokens();

    User getByAccountId(long id);

    String getNameByAccountId(long id);

    void updatePassword( String newPassword,Long paramId);

    Set<Role> findAllRoles();
}
