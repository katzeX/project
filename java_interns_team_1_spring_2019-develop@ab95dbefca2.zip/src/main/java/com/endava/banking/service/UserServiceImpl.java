package com.endava.banking.service;

import com.endava.banking.controller.dto.UserRegistrationDto;
import com.endava.banking.model.*;
import com.endava.banking.repository.AccountRepository;
import com.endava.banking.repository.UserRepository;
import com.endava.banking.repository.VerificationTokenRepository;
import com.endava.banking.utils.RandomLong;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;


    @Autowired
    private VerificationTokenRepository tokenRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private AccountService accountService;

    @Autowired
    private AccountRepository accountRepository;

    public User findByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public User update(UserRegistrationDto registration) {
        User user = new User();
        user.setFirstName(registration.getFirstName());
        user.setLastName(registration.getLastName());
        user.setEmail(registration.getEmail());
        user.setPassword(passwordEncoder.encode(registration.getPassword()));
        user.setNotificationToken(UUID.randomUUID().toString());
        return user;
    }

    @Override
    public User update(User user) {
        User user1 = userRepository.save(user);

        //Default user Role
        assighnRole(2L, user.getId());
        User savedUser = userRepository.findByEmail(user1.getEmail());
        accountService.save(new Account(RandomLong.getRandomNumberInRange(), savedUser.getId(), 1000, 1));
        return user;
    }

    @Override
    public List<User> findAll() {
        return userRepository.findAllUsersAndRole();
    }

    @Override
    public User getById(long id) {
        return userRepository.getOne(id);
    }

    @Override
    public void updateStatus(UserStatus userStatus, Long id) {
        userRepository.updateStatus(userStatus, id);
    }

    @Override
    public void updateRole(int newRoleId, Long id) {
        userRepository.updateRole(newRoleId, id);
    }

    @Override
    public User getUser(String verificationToken) {
        return tokenRepository.findByToken(verificationToken).getUser();
    }

    @Override
    public void createVerificationToken(User user, String token) {
        VerificationToken myToken = new VerificationToken(token, user);
        tokenRepository.save(myToken);
    }

    @Override
    public VerificationToken getVerificationToken(String verificationToken) {
        return tokenRepository.findByToken(verificationToken);
    }

    @Override
    public void assighnRole(Long newRole, Long newUserId) {
        userRepository.assignRole(newRole, newUserId);
    }

    @Override
    public void deleteUserById(Long id) {
        userRepository.deleteUserById(id);
    }

    @Override
    public void deleteVerificationTokenByUserId(Long id) {
        tokenRepository.deleteToeknByUserId(id);
    }

    @Override
    public void deleteUserRolesById(Long userId) {
        userRepository.deleteUserRolesById(userId);
    }

    @Override
    public void deleteUserAfterLinkExpired(Long userId) {
        deleteUserRolesById(userId);
        deleteVerificationTokenByUserId(userId);
        deleteUserById(userId);
        accountRepository.deleteAccountByUserId(userId);
    }

    @Override
    public void dropOldTokens() {

        Calendar calendar = Calendar.getInstance();
        for (VerificationToken tokens : tokenRepository.findAll()
        ) {
            if ((tokens.getExpiryDate().getTime() - calendar.getTime().getTime()) <= 0) {
                tokenRepository.deleteById(tokens.getId());
            }
        }
    }

    @Override
    public User getByAccountId(long id) {
        return userRepository.getOne(accountService.getByID(id).getIdCustomer());
    }

    @Override
    public String getNameByAccountId(long id) {
        String firstName = userRepository.getOne(accountService.getByID(id).getIdCustomer()).getFirstName();
        String lastName = userRepository.getOne(accountService.getByID(id).getIdCustomer()).getLastName();
        return (firstName + " " + lastName);
    }

    @Override
    public void updatePassword(String newPassword, Long paramId) {
        userRepository.updatePassword(passwordEncoder.encode(newPassword), paramId);
    }

    @Override
    public Set<Role> findAllRoles() {
        return userRepository.findAllRoles();
    }

    @Override
    public UserDetails loadUserByUsername(String email) {
        User user = userRepository.findByEmail(email);

        if (user == null) {
            throw new UsernameNotFoundException("Invalid username or password.");
        }
        Set<GrantedAuthority> grantedAuthorities = new HashSet<>();
        for (Role role : user.getRoles()) {
            grantedAuthorities.add(new SimpleGrantedAuthority(role.getName()));
        }

        return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(), grantedAuthorities);
    }

}
