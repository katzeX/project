package com.endava.banking.service;

import com.endava.banking.model.Account;
import com.endava.banking.model.ServicesProvider;
import com.endava.banking.repository.AccountRepository;
import com.endava.banking.repository.CompanyRepository;
import com.endava.banking.model.Company;
import com.endava.banking.utils.RandomLong;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class CompanyService implements CompanyServiceInterface {


    @Autowired
    private CompanyRepository companyRepositoryInterface;

    @Autowired
    private AccountService accountService;

    @Autowired
    private AccountRepository accountRepository;


    @Override
    public Company add(Company object) {
        Company theCompany =
                companyRepositoryInterface.save(object);
        accountService.save(new Account(RandomLong.getRandomNumberInRange(), object.getIdCustomer(), 1000, 2));

        return theCompany;
    }

    @Override
    public List<Company> findAll() {
        return companyRepositoryInterface.findAll();
    }

    @Override
    public Company getById(long id) {
        return companyRepositoryInterface.getOne(id);
    }

    @Override
    public void update(Company newObject) {
        companyRepositoryInterface.save(newObject);
    }

    @Override
    public void delete(long id) {
        companyRepositoryInterface.deleteById(id);
        accountRepository.deleteAccountByUserId(id);
    }

    @Override
    public Company getByName(String name) {
        return companyRepositoryInterface.getByName(name);
    }

    @Override
    public List<Company> getAllByServicesProvided(ServicesProvider servicesProvider) {
        return companyRepositoryInterface.getAllByServicesProvided(servicesProvider);
    }
}
