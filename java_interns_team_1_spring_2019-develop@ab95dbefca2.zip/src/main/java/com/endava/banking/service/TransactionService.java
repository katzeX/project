package com.endava.banking.service;

import com.endava.banking.controller.dto.TransactionInfoDto;
import com.endava.banking.controller.dto.TransactionInfoSelectDto;
import com.endava.banking.controller.dto.UserTransactionsDto;
import com.endava.banking.model.*;
import com.endava.banking.repository.AccountRepository;
import com.endava.banking.repository.TransactionsRepository;
import com.endava.banking.utils.Transfer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import static com.endava.banking.model.PaymentStatus.*;


@Service
public class TransactionService {
    @Autowired
    private TransactionsRepository transactionRepo;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private Transfer transfer;

    public List<Transactions> getAll() {
        return transactionRepo.findAll();
    }

    public void add(Transactions transactions) {
        transactionRepo.save(transactions);
    }

    public void remove(long id) {
        transactionRepo.deleteById(id);
    }

    public PaymentStatus transfer(long fromAccount, long toAccount, float amount) {
        Date utilDate = new Date();
        Timestamp ts = new Timestamp(utilDate.getTime());
        PaymentStatus paymentStatus;
        Account accountFrom = accountRepository.getOne(fromAccount);
        if (accountFrom.getBalance() >= amount && amount <= 10000) {
            paymentStatus = DONE;
            transfer.transfer(fromAccount, toAccount, amount);
        } else if (accountFrom.getBalance() >= amount && amount > 10000) {
            paymentStatus = PENDING;
        } else {
            paymentStatus = REJECTED;
        }
        transfer.transactions(fromAccount, toAccount, amount, ts, paymentStatus);
        return paymentStatus;
    }

    public List<Transactions> getAllPending() {
        return transactionRepo.getByStatus(PENDING);
    }

    public void approvePending(Transactions transactions) {
        if (accountRepository.getOne(transactions.getFromAccount()).getBalance() >= transactions.getAmount()) {
            transfer.transfer(transactions.getFromAccount(), transactions.getToAccount(), transactions.getAmount());
            transactions.setStatus(DONE);
            transactionRepo.save(transactions);
        } else {
            transactions.setStatus(REJECTED);
            transactionRepo.save(transactions);
        }
    }

    public void declinePending(Transactions transactions) {
        transactions.setStatus(REJECTED);
        transactionRepo.save(transactions);
    }

    public Transactions getByID(long id) {
        return transactionRepo.getOne(id);
    }

    public List<UserTransactionsDto> getAllUserTransactions(List<UserTransactionsDto> from, List<UserTransactionsDto> to) {

        List<UserTransactionsDto> userTransactionsDtos = new ArrayList<>();
        userTransactionsDtos.addAll(from);
        userTransactionsDtos.addAll(to);

        userTransactionsDtos.sort(Collections.reverseOrder());

        return userTransactionsDtos;

    }

    public Float getTransactionsAmount(long idAccount) {
        if (transactionRepo.getTransactionsAmount(idAccount) == null) {
            return 0f;
        }
        return transactionRepo.getTransactionsAmount(idAccount);
    }

    public Float getComunalPayments(long idAccount) {
        if (transactionRepo.getComunalPayments(idAccount) == null) {
            return 0f;
        } else return transactionRepo.getComunalPayments(idAccount);
    }

    public Float getItPayments(long idAccount) {
        if (transactionRepo.getItPayments(idAccount) == null) {
            return 0f;
        } else return transactionRepo.getItPayments(idAccount);
    }

    public Page<UserTransactionsDto> findPaginated(Pageable pageable, List<UserTransactionsDto> dtos) {

        int pageSize = pageable.getPageSize();
        int currentPage = pageable.getPageNumber();
        int startItem = currentPage * pageSize;
        List<UserTransactionsDto> list;

        if (dtos.size() < startItem) {
            list = Collections.emptyList();
        } else {
            int toIndex = Math.min(startItem + pageSize, dtos.size());
            list = dtos.subList(startItem, toIndex);
        }

        return new PageImpl<>(list, PageRequest.of(currentPage, pageSize), dtos.size());
    }

    public Page<TransactionInfoDto> findPaginatedTransactions(Pageable pageable, List<TransactionInfoDto> dto) {

        int pageSize = pageable.getPageSize();
        int currentPage = pageable.getPageNumber();
        int startItem = currentPage * pageSize;
        List<TransactionInfoDto> list;

        if (dto.size() < startItem) {
            list = Collections.emptyList();
        } else {
            int toIndex = Math.min(startItem + pageSize, dto.size());
            list = dto.subList(startItem, toIndex);
        }

        return new PageImpl<>(list, PageRequest.of(currentPage, pageSize), dto.size());
    }

    public List<UserTransactionsDto> retrieveTransactionsFromAsDTO(long idAccount) {
        return transactionRepo.retrieveTransactionsFromAsDTO(idAccount);
    }

    public List<UserTransactionsDto> retrieveTransactionsToAsDTO(long idAccount) {
        return transactionRepo.retrieveTransactionsToAsDTO(idAccount);
    }

    public List<TransactionInfoSelectDto> getSelectFrom() {
        return transactionRepo.getSelectFrom();
    }

    public List<TransactionInfoSelectDto> getSelectTo() {
        return transactionRepo.getSelectTo();
    }

    public List<TransactionInfoDto> getTransactionsInfo() {
        List<TransactionInfoDto> list = new ArrayList<>();
        List<TransactionInfoSelectDto> from = getSelectFrom();
        List<TransactionInfoSelectDto> to = getSelectTo();
        for (TransactionInfoSelectDto t:from) {
            list.add(new TransactionInfoDto(t.getId(),t.getFrom(),t.getTo(),t.getAmount(),t.getDate(),t.getStatus(),t.getIdk(),t.getType()));
        }
        for (TransactionInfoSelectDto t:to) {
            for (TransactionInfoDto tr:list) {
                if (t.getTo()==tr.getTo()){tr.setTo_name(t.getIdk());}
            }
        }
        return list;
    }
}
