package com.endava.banking.service;


import com.endava.banking.model.Company;
import com.endava.banking.model.ServicesProvider;

import java.util.List;

public interface CompanyServiceInterface {

    Company add(Company object);

    List<Company> findAll();

    Company getById(long id);

    void update(Company newObject);

    void delete(long id);

    Company getByName(String name);

    List<Company> getAllByServicesProvided(ServicesProvider servicesProvider);

}
