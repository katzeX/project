package com.endava.banking.service;

import com.endava.banking.controller.dto.AccountInfoDto;
import com.endava.banking.model.Account;
import com.endava.banking.repository.AccountRepository;
import com.endava.banking.repository.CompanyRepository;
import com.endava.banking.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private CompanyRepository companyRepository;


    public boolean existsAccountByIdAccount(long id) {
        return accountRepository.existsAccountByIdAccount(id);
    }

    public boolean existsAccountByIdCustomer(long id) {
        return accountRepository.existsAccountByIdCustomer(id);
    }

    public Account getAccountByIdCustomerAndAccountType(long idCustomer, int accountType) {
        return accountRepository.getAccountByIdCustomerAndAccountType(idCustomer, accountType);
    }

    public List<Account> getAll() {
        return accountRepository.findAll();
    }

    public List<AccountInfoDto> getAccountsInfo(){return accountRepository.getAccountsInfo();}

    public Account getByID(long id) {
        return accountRepository.getOne(id);
    }

    public void update(long id, Account account) {
        Account auxaccount;
        auxaccount = accountRepository.findById(id).get();
        auxaccount.setBalance(account.getBalance());
        accountRepository.save(auxaccount);
    }

    public Account getAccountByIdCustomer(Long id) {
        return accountRepository.getAccountByIdCustomer(id);
    }

    public void save(Account account) {
        accountRepository.save(account);
    }

    public String getUserName(long id){
        return userRepository.getOne(id).getFirstName()+" "+userRepository.getOne(id).getLastName();}

    public String getCompanyName(long id){return companyRepository.getOne(id).getName();}

    public void creditPayment(long id, float amount) {
        Account account = accountRepository.getOne(id);
        account.setBalance(account.getBalance() - amount);
        update(id, account);
    }

    public void creditDeposit(long id, float amount) {
        Account account = accountRepository.getOne(id);
        account.setBalance(account.getBalance() + amount);
        update(id, account);
    }
}
