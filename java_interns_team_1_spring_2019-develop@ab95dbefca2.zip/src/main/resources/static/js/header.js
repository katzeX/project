$(document).ready(function () {
    $("#company").click(function () {
        $("#div1").load("/banking/company/find")
    });
    $("#users").click(function () {
        $("#div1").load("/banking/users/find")
    });
    $("#account").click(function () {
        $("#div1").load("/banking/account")
    });
    $("#transactions").click(function () {
        $("#div1").load("/banking/transactions")
    });
    $("#approvements").click(function () {
        $("#div1").load("/banking/transaction/approvements")
    });

    $("#update").click(function () {
        $("#div1").load("/banking/users/find")
    });
});
var parser = document.createElement('a');
parser.href = window.location.href;
console.log(parser.hash);
switch (parser.hash) {
    case '#account': {
        $(document).ready(function () {
            $("#div1").load("/banking/account")
        });
    }
        break;

    case '#approvements': {
        $(document).ready(function () {
            $("#div1").load("/banking/transaction/approvements")
        });
    }
        break;

    case '#company': {
        $(document).ready(function () {
            $("#div1").load("/banking/company/find")
        });
    }

        break;

    case '#users': {
        $(document).ready(function () {
            $("#div1").load("/banking/users/find")
        });
    }

        break;

    case '#transactions': {
        $(document).ready(function () {
            let searchParams = new URLSearchParams(window.location.search);
            var page = searchParams.get('page');
            var size = searchParams.get('size');
            $("#div1").load("/banking/transactions?page="+page+"&size="+size)
        });
    }

        break;
}



