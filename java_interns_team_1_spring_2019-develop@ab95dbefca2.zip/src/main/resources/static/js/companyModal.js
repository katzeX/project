$(document).ready(function () {

    $(' .table .eBtn').on('click', function (event) {
        event.preventDefault();
        var href = $(this).attr('href');
        $.get(href, function (company, status) {
            $(' .myForm #idCustomer').val(company.idCustomer);
            $(' .myForm #name').val(company.name);
            $(' .myForm #servicesProvided').val(company.servicesProvided);
        })
        $('.myForm #exampleModal').modal();
    });

    $(' .table .delBtn').on('click', function (event) {
        event.preventDefault();
        var href = $(this).attr('href');
        $('#exampleModalCenter #delRef').attr('href', href)
        $('#exampleModalCenter').modal();

    });

    $(' .nBtn').on('click', function (event) {
        event.preventDefault();
        $(' .myAddForm #id').val(0);
        $(' .myAddForm #nName').val('');
        $(' .myAddForm #sServices').val('');
        $(' .myAddForm #exampleAddModal').modal();
    });

});