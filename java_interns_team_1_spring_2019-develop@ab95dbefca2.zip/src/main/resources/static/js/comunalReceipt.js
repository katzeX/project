(function ($) {
    $.getQuery = function (query) {
        query = query.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var expr = "[\\?&]" + query + "=([^&#]*)";
        var regex = new RegExp(expr);
        var results = regex.exec(window.location.href);
        if (results !== null) {
            return results[1];
        } else {
            return false;
        }
    };
})(jQuery);

function populate() {
    var meterTypeGenerated = "";
    var possible = "RST";

    for (var i = 0; i < 1; i++)
        meterTypeGenerated += possible.charAt(Math.floor(Math.random() * possible.length));

    var meterNr = Math.floor(Math.random() * 1000000);
    document.getElementById("invoiceNumber").value = $.getQuery('invoice');
    document.getElementById("meterType").value = meterTypeGenerated;
    document.getElementById("meterNr").value = Math.floor(Math.random() * 1000000);
    document.getElementById("meterIndices").value = Math.floor(Math.pow(10, 3) + Math.random() * 9 * Math.pow(10, 3));
    document.getElementById("amount").value = (Math.random() * (1000.00 - 1.00 + 1.00) + 1.00).toFixed(2)
}