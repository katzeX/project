$(document).ready(function () {


    var it = $("#paymentItAmount").val();
    var comunal = $("#paymentComunalAmount").val();
    var transactions = $("#transactionAmount").val();
    new Chart($("#canvas1"), {
        type: 'doughnut',
        tooltipFillColor: "rgba(51, 51, 51, 0.55)",
        data: {
            labels: [
                "IT",
                "Comunal",
                "Transactions"
            ],
            datasets: [{
                data: [it, comunal, transactions],
                backgroundColor: [
                    "#3498DB",
                    "#FFCC33",
                    "#FE6227"
                ],
                hoverBackgroundColor: [
                    "#49A9EA",
                    "#FFCC33",
                    "#FE6227"
                ]
            }]
        },
        options: {responsive: false}
    });
});

function demoFromHTML() {
    var pdf = new jsPDF('p', 'pt', 'letter');
    pdf.text(230, 50, "Transactions List");
    source = $('#pdf')[0];

    specialElementHandlers = {
        '#bypassme': function (element, renderer) {
            return true
        }
    };
    margins = {
        top: 80,
        bottom: 60,
        left: 60,
        width: 522
    };
    pdf.fromHTML(
        source,
        margins.left,
        margins.top, {
            'width': margins.width,
            'elementHandlers': specialElementHandlers
        },
        function (dispose) {
            pdf.save('Transactions.pdf');
        }
        , margins);
}

$(document).ready(function () {
    $("#myInput").on("keyup", function () {
        var value = $(this).val().toLowerCase();
        $("#myTable tr").filter(function () {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
});