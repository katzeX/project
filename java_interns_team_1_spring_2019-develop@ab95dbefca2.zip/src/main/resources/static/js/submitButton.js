
$(document).ready(function () {

    $("#paymentForm").submit(function () {

        //disable the submit button
        $("#submit").attr("disabled", true);
        return true;

    });
});

$(document).ready(function(){
    $('#payments').addClass('active');
});
