$(document).ready(function () {

    $(' .table .eBtn').on('click', function (event) {
        event.preventDefault();
        var href = $(this).attr('href');
        $.get(href, function (user, status) {
            $(' .myForm #id').val(user.id);
            $(' .myForm #name').val(user.firstName);
            $(' .myForm #firstName').val(user.firstName);
            $(' .myForm #lastName').val(user.lastName);
            $(' .myForm #email').val(user.email);
            $(' .myForm #userStatus').val(user.userStatus);
            $(' .myForm #roleName').val(user.roleName);
        })
        $('.myForm #exampleModal').modal();
    });

});

