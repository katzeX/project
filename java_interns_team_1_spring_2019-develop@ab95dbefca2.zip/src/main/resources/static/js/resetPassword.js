$(document).ready(function () {

    $(' .rBtn').on('click', function (event) {
        event.preventDefault();
        $(' .passModal #password').val('');
        $(' .passModal #examplePassModal').modal();
    });

});